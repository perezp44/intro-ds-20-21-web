#- script para la clase 08 

#- https://github.com/tidyverse/ggplot2/issues/3993

#- lo primero y MAS IMPORTANTE: No hay q agobiarse!!!: https://perezp44.github.io/intro-ds-20-21-web/tutoriales/tt_01_introduccion.html#3_Ciencia_de_Datos


library(tidyverse)
#- ggplot2 ----------------------------------------------------------------------------

# continuamos con slides_06(B) pero antes RECORDAMOS un poco:

p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()

#- en realidad cada capa está compuesta de datos, aes(), geom_xx, PERO tb de: stats(), position
p + geom_point(position = "jitter", color = "pink", size = 0.9)
p + geom_point(position = position_jitter(width = 0.7, height = 0.3), color = "pink", size = 0.9)

p + geom_point(stat = "smooth", color = "pink", size = 0.9)


#- las opciones de cada geom_xx en: https://www.yihanwu.ca/post/geoms-and-aesthetic-parameters/
#- aún más completo: http://sape.inf.usi.ch/quick-reference/ggplot2/geom_point
#- por ejemplo geom_vline(), sus parámetros son: xintercept, size, linetype, colour, alpha
p + geom_vline(xintercept = 5.0, size = 0.7, linetype = 2, colour = "black", alpha = 0.7)


#- 3.1 titulos ------------------------------------------------------------------
p + labs(title = "Gráfico 1: Longitud del sépalo frente al pétalo",
         subtitle = "(diferenciando por especie de lirio)",
         caption = "Datos provenientes del Iris dataset",
         x = "Longitud del sépalo",
         y = "Longitud del pétalo",
         color = "Especie de lirio",
         tag = "Plot 1")

#- 3.2 themes -------------------------------------------------------------------
p + theme_minimal() 

#- puedo definir mi propio theme
my_theme <- theme(
  axis.text.x = element_text(colour = "blue", size = 12, angle = 78, hjust = 0.5, vjust = 0.5) ,
  axis.text.y = element_text(colour = "red", size = 12), 
  text = element_text(size = 13, colour = "green"))

p + my_theme


#- 3.3 facetting -----------------------------------------------------------------
p + facet_grid(cols = vars(Species))   # gráficos x columnas
p + facet_grid(rows = vars(Species))   # gráficos x filas
p + facet_wrap(vars(Species), nrow = 2, ncol = 2) # graf x filas y columnas


#- Se me olvidó nombrar las cheatsheets:  https://rstudio.com/resources/cheatsheets/
#- cheatsheet de ggplot2 en castellano: https://rstudio.com/wp-content/uploads/2016/12/ggplot2-cheatsheet-2.1-Spanish.pdf

#- El gráfico de los Simpsons: https://twitter.com/_Gil_Henriques/status/1166373844040335360?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1166373844040335360&ref_url=file%3A%2F%2F%2Fhome%2Fpjpv%2FEscritorio%2Fclase_07%2Ftt_06_ggplot2.html
#- Eva Marey: https://evamaerey.github.io/tidytuesday_walk_through/simpsons.html#1



#- NUEVO: empezamos con material NUEVO ------------------------------------------------

# Veamos algunos elementos más: anotaciones, 

#- 3.4 anotaciones --------------------------------------------------------------
# anotaciones con annotate()
p + annotate(geom = "text", x = 6, y = 2, label = "Una anotación", size = 5) +
    annotate("rect", xmin = 6, xmax = 7,ymin = -Inf, ymax = Inf, alpha = 0.2, fill = "pink") + 
    annotate("segment", x = 5, xend = 7, y = 6, yend = 8, colour = "blue")

# anotaciones con geom_text()
p + geom_text(aes(label = Petal.Length)) + geom_text(aes(label = Species))
p + geom_text(aes(label = Species), size = 1.9) + geom_text(aes(label = Petal.Length))
# no parece muy útil pero con un poco de imaginación/cuidado
iris_max <- iris %>% group_by(Species) %>% slice_max(Petal.Length, n = 1)
p + geom_text(data = iris_max, aes(label = Species), color = "black", size = 3) 
p + geom_text(data = iris_max, aes(label = Species), color = "black", size = 3, hjust = "left") 

# Anotaciones con geom_xx_line()
p + geom_vline(xintercept = 6)
p + geom_hline(yintercept = 5, size = 1.7, colour = "purple", linetype = "dashed")
p + geom_abline(intercept = 0.7, slope = 0.4, size = 1.9, colour = "steelblue")

#- 3.5 límites de los ejes -------------------------------------------------------
#limites: x[4-8] y[1-7] 
p + lims(x = c(NA,6)) + lims(y = c(1,8)) + lims(color = c("setosa"))  

#- 3.6 escalas -------------------------------------------------------------------
p + scale_colour_continuous()
pp <- ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point()
pp + geom_point(aes(color = Petal.Width)) + scale_colour_continuous()

p + scale_colour_brewer(palette = 2)
p + scale_x_continuous(breaks = seq(3, 10.5, 1.5), limits = c(3, 10.5)) + 
    scale_y_continuous(breaks = seq(0, 12, 3), limits = c(0, 12), label = scales::dollar)

#- 3.7. Stats --------------------- slides (B)  ----------------------------------

#- 3.8 Position adjustments ------- slides (B)  ----------------------------------

#- 4. Combinando gráficos --------- slides (B)  ----------------------------------

#- 5. Exportando gráficos --------  slides (B)  ----------------------------------

#- 6. Tipos de gráficos ----------  slides (C)  ----------------------------------

#- 7. Más detalles/cosas ----  mira un poco en el tutorial   ---------------------

#- 8. Asistentes ggplot2 ----------  slides (B)  ---------------------------------
library(ggThemeAssist)    #- install.packages("ggThemeAssist")
library(esquisse)         #- install.packages("esquisse")
library(ggannotate)       #- remotes::install_github("mattcowgill/ggannotate")
iris <- iris
p
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()


#- 6. Tipos de gráficos ----------  slides (C)  ----------------------------------

#- 6.1 Histogramas

iris_backgroung <- iris %>% select(-Species)
ggplot(iris, aes(x = Sepal.Length)) +
  geom_histogram(data = iris_backgroung, fill = "grey", bins = 15) +
  geom_histogram(aes(fill = Species), bins = 15) +
  facet_grid(cols = vars(Species))

ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_density(position = "stack", alpha = 0.5) 
ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_density(position = "identity", alpha = 0.5) 

ggplot(iris, aes(x = Sepal.Length, y = Species)) + 
  ggridges::geom_density_ridges(aes(fill = Species), alpha = 0.5)

#- 6.2 Scatter plot

#- 6.3 Gráficos de caja (Boxplots)
# reordenar los grupos
ggplot(iris, aes(x = Species,  y = Sepal.Width)) + geom_boxplot()
ggplot(iris, aes(x = reorder(Species, Sepal.Width, mean),  y = Sepal.Width)) + geom_boxplot() +
xlab("De menor a mayor anchura del sépalo")

#- 6.4 Gráficos de barra (Boxplots)
p <- ggplot(mpg, aes(class))
p + geom_bar()
p + geom_bar(fill = "steelblue") + coord_flip()
# ya no hace falta coord_flip()
p <- ggplot(mpg, aes(y =class))
p + geom_bar()

# reordenando las categorias
df <- mpg
df <- df %>% mutate(class = forcats::as_factor(class)) #- convertimos la v. class a factor con la f. as_factor()
df <- df %>% mutate(class = forcats::fct_infreq(class)) #- fct_infreq() los niveles del factor según su frecuencia de mayor a menor
p <- ggplot(df, aes(fct_rev(class))) #- fct_rev() ordena los levels de menor a mayor
p + geom_bar(fill = "steelblue") + coord_flip()



#- 10. Gráficos interactivos -------------------------------

# lo más fácil con plotly
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) +  geom_point() + geom_smooth()

plotly::ggplotly(p)

#- Mirando en la gallery, me decidi por este:https://erblast.github.io/parcats/
library(parcats)    #- devtools::install_github("erblast/parcats")
require(easyalluvial)
iris <- iris %>% select(Species, Sepal.Length, Petal.Length)
p <- alluvial_wide(iris, max_variables = 3)
p
parcats(p, marginal_histograms = TRUE, data_input = mtcars2)



#- RMARKDOWN ------------------------------------------------------------------