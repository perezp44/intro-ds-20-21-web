#- script para gestionar el Rproject:
#- con este script iremos bajando los diferentes ejemplos q usemos en clase
#----------------------------------------------------------------------------

#- Para bajar un ejemplo concreto has de:

file_to_download <- "tt_01_introduccion_v3.html" #- has de poner el nombre del archivo que quieres bajarte

url <- paste0("https://github.com/perezp44/tutoriales_intro_DS/raw/master/", file_to_download)

download.file(url, destfile = file_to_download)
