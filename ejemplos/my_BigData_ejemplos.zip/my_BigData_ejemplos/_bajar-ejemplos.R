#- script para gestionar el Rproject:
#- con este script iremos bajando los diferentes ejemplos q usemos en clase
#----------------------------------------------------------------------------
#- file_to_download <- "tt_01_introduccion_v3.html" #- has de poner el nombre del archivo que quieres bajarte
#- Para bajar un ejemplo concreto has de pegar en el hueco de abajo (por ejemplo en la línea 7 ó 8) el código que has copiado de las transparencias




url <- paste0("https://github.com/perezp44/intro-ds-20-21-web/raw/master/ejemplos/", file_to_download)

download.file(url, destfile = file_to_download)

