#- Ejemplo nº 00 del curso
#- Vamos a hacer memes con el pkg "meme"
#- repo del paquete:  https://github.com/GuangchuangYu/meme/

library(meme)    #- install.packages("meme")

fotaca <- system.file("success.jpg", package = "meme")

meme(fotaca, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0, color = "purple")


#- segundo meme, usamos una foto que está en internet
fotaca <- "https://i1.wp.com/production-wordpress-assets.s3.amazonaws.com/blog/wp-content/uploads/2013/03/wisdom_of_the_ancients-1.png?resize=485%2C270&ssl=1"

meme(fotaca, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0 , color = "purple")


