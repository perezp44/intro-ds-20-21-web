#- Ejemplo nº 00 del curso
#- Vamos a hacer memes con el pkg "meme"
#- repo del paquete:  https://github.com/GuangchuangYu/meme/

library(meme)    #- install.packages("meme")

#- primer meme, la foto está dentro del package "meme"
fotaca <- system.file("success.jpg", package = "meme")

meme(fotaca, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0, color = "purple")


#- segundo meme: usamos una foto que está en internete
fotaca <- "https://i1.wp.com/production-wordpress-assets.s3.amazonaws.com/blog/wp-content/uploads/2013/03/wisdom_of_the_ancients-1.png?resize=485%2C270&ssl=1"

meme(fotaca, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0 , color = "purple")


#- tercer meme: utilizamos uan foto de nuestro ordenador. La foto está en "./imagenes/NV.jpg"
fotaca <- "./imagenes/NV.jpg"
fotaca <- here::here("imagenes", "NV.jpg")  #- usaremos el paquete here para crear las rutas
meme(fotaca, "SÍ q puedes!!!", "Tú puedes aprender R!!", size = 2.0 , color = "purple")


#- Por cierto, hay paquetes más completos para hacer memes, pero este seguro que nos funcionaba. Si te interesa el tema mira este post: http://jenrichmond.rbind.io/post/making-memes-in-r/
