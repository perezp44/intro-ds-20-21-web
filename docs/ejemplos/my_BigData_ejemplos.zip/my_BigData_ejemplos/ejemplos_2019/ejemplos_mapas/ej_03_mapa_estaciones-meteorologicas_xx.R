#- basado en: https://www.datanalytics.com/2019/10/21/si-non-e-vero-non-e-vero-que-se-le-va-a-hacer/

library (tidyverse)

#- mapa del mundo con ggplot()
library("rnaturalearth")
library("rnaturalearthdata")
world <- ne_countries(scale = "medium", returnclass = "sf")
p <- ggplot() + geom_sf(data = world)

#- estaciones meteorológicas
library(stationaRy)
stations <- get_station_metadata()
stations_es <- stations %>% filter(country == "SP")




#- ejercicio 1: mapa con las long/lat de las estaciones


#- ejercicio 2: mapa para españa


#- obtenemos datos meteorológicos: https://github.com/rich-iannone/stationaRy
stations_val_id <- stations %>% filter( str_detect(name, "^VALENCIA") ) %>% pull(id)


# datos <- purrr::map(stations_val_id, get_met_data, years = 2019)
# datos_df <- datos %>% as_tibble( .name_repair = "unique")   #- nos lo pone todo junto
# datos_1 <- datos[[1]]                                       #- los datos de la primera estacion de valencia


datos_1 <- get_met_data("080143-99999",years = 2019)


ggplot(datos_1, aes(x = time, y = temp)) + geom_line()


