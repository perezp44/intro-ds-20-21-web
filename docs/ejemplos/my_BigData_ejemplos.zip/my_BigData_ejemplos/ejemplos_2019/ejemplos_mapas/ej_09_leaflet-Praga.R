#- https://www.jla-data.net/eng/leaflet-in-r-tips-and-tricks/index.html

library(sf)             # for working with spatial data
library(dplyr)          # data frame manipulation
library(leaflet)        # because leaflet :)
library(htmltools)      # tools to support html workflow
library(rnaturalearth)  # interface to https://www.naturalearthdata.com/
library(leaflet.extras) # extending the leaflet.js


# set up a data frame of points
body <- data.frame(name = c("Kramářova vila", "Pražský hrad", "Strakova akademie", "Nejvyšší soud", "Ústavní soud", "Sněmovna", "Senát"),
                   branch = c("executive", "executive", "executive", "judiciary", "judiciary", "legislature", "legislature"),
                   link = c("https://en.wikipedia.org/wiki/Kram%C3%A1%C5%99%27s_Villa",
                            "https://en.wikipedia.org/wiki/Prague_Castle",
                            "https://en.wikipedia.org/wiki/Straka_Academy",
                            "https://en.wikipedia.org/wiki/Supreme_Court_of_the_Czech_Republic",
                            "https://en.wikipedia.org/wiki/Constitutional_Court_of_the_Czech_Republic",
                            "https://en.wikipedia.org/wiki/Chamber_of_Deputies_of_the_Czech_Republic",
                            "https://en.wikipedia.org/wiki/Senate_of_the_Czech_Republic"),
                   lat = c(14.4104392, 14.3990089, 14.4117831, 16.6021958, 16.6044039, 14.4039458, 14.4053489),
                   lon = c(50.0933681, 50.0895897, 50.0920997, 49.2051925, 49.1977642, 50.0891494, 50.0900269))


# transform the data frame from plain vanilla one to spatial
body <- body %>%
  sf::st_as_sf(coords = c("lat", "lon"), # columns with geometry
               crs = 4326) # WGS84 is a sensible default...


# first prepare a leaflet plot ...
lplot <- leaflet::leaflet(data = body) %>% # create leaflet object
  leaflet::addTiles() %>% # add basemap
  leaflet::addMarkers() # add data layer - markers

lplot #  ... then display it


#- saving the prepared leaflet plot as a html file
# htmltools::save_html(lplot, "leaflet.html")




# first prepare a leaflet plot ...
lplot <- leaflet(body) %>%
  leaflet::addProviderTiles("Stamen.Toner") %>%
  addMarkers(popup = ~htmltools::htmlEscape(name)) # note the tilde! ~

lplot #  ... then display it




# prepare a palette - manual colors according to branch column
palPwr <- leaflet::colorFactor(palette = c("executive" = "red",
                                           "judiciary" = "goldenrod",
                                           "legislature" = "steelblue"),
                               domain = body$branch)

# first prepare a leaflet plot ...
lplot <- leaflet(body) %>%
  addProviderTiles("Stamen.Toner") %>% # consider also "CartoDB.Positron"
  addCircleMarkers(radius = 10, # size of the dots
                   fillOpacity = .7, # alpha of the dots
                   stroke = FALSE, # no outline
                   popup = ~htmlEscape(name),
                   color = palPwr(body$branch),
                   clusterOptions = markerClusterOptions()) %>%
  leaflet::addLegend(position = "bottomright",
            values = ~branch, # data frame column for legend
            opacity = .7, # alpha of the legend
            pal = palPwr, # palette declared earlier
            title = "Branch") %>%  # legend title
  leaflet.extras::addResetMapButton()

lplot #  ... then display it
