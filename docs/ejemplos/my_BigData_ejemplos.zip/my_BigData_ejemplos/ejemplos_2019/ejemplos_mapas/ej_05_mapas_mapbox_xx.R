#- https://github.com/adam-gruer/30DayMapChallenge/blob/master/Day01bPoints.Rmd
#- https://twitter.com/AdamGruer/status/1190590913589833729
#- https://github.com/adam-gruer/victor
#- necesitas un token de Mapbox:

library(tidyverse)
library(sf)
library(here)
library(magrittr)
library(patchwork)
library(magick)
library(victor) #-   remotes::install_github("adam-gruer/victor")

#- descargamos un df con las ciudades del mundo
urla <- "https://simplemaps.com/static/data/world-cities/basic/simplemaps_worldcities_basicv1.5.zip"
download.file(urla, here::here("datos", "pruebas", "worldcities.zip"))
unzip(zipfile =here::here("datos", "pruebas", "worldcities.zip"),
      exdir = here::here("datos", "pruebas"))

world_cities <- read_csv(here::here("datos", "pruebas", "worldcities.csv"))


#- mapa con las ciudades del mundo

world_cities %>% ggplot() + geom_point(aes(x = lat, y = lng))

#- ejercicio 3: lo mejorais?


#- ejercicio 4: hay que quitar la leyenda


#- voy a bajar datos de Maptools de 3 ciudades españolas -----------------------------------
#- voy a bajar datos de Maptools de 3 ciudades españolas -----------------------------------
#selected_cities <- world_cities %>% filter((city == "Valencia" & iso3 == "ESP") | 
                                            (city == "Madrid" & iso3 == "ESP") |
                                            (city == "Barcelona" & iso3 == "ESP")) %>%
                                select(city, lon = lng, lat) %>% transpose()

#cities_data <- map(selected_cities,  ~ victor::spoils(.x$lon, .x$lat, zoom = 15, nrow = 13, ncol = 13 ))
#valencia <- cities_data[[1]]
#saveRDS(cities_data, here::here("datos", "cities_data.RDS"))
#- al final tb lo subí a Github
#------ arriba es descarga de datos --------------------------------------------------------

#cities_data <- rio::import("./datos/cities_data.RDS")
cities_data <- rio::import("https://github.com/perezp44/archivos_download/raw/master/cities_data.RDS")

transit_stops <- purrr::map(cities_data, "transit_stop_label")
valencia <- cities_data[[1]]

# transit_stops$Valencia %>% st_drop_geometry() %>% View()   #- para ver Valencia

maps <- imap(transit_stops, ~
ggplot() + geom_sf(data = .x , aes(colour = mode), size = 0.5,alpha = 0.6, show.legend = "point") +
  annotate("text", -Inf, Inf, label = toupper(.y), hjust = 0, vjust = 1, colour = "white", alpha = 0.6, size = 8) +
  guides(color = guide_legend(title = NULL, ncol = 3, override.aes = list(size = 3, alpha = 1))) +
  ggthemes::scale_color_tableau() +
  theme_void() +
  theme(
    panel.background = element_rect(fill = "black"),
    plot.margin = margin(0, 2, 0, 2),
    legend.position = c(0.1, 0.02),
    legend.background = element_rect(fill = NA),
    legend.direction = "horizontal",
    legend.justification = c(0.1, 0),
    legend.text = element_text(colour = "white")
  ))


maps[[2]] #- el mapa de valencia

patchwork::wrap_plots(maps) #- vemos los mapas de las 3 ciudades


#- guardamos el grafico
ggsave(here("estaciones_3-ciudades.png"), width = 10, height = 6)


transit_stop <- image_read(here("estaciones_3-ciudades.png"))
image_crop(transit_stop, "3000x1000+0+400") %>%
  image_fill( "grey5", point = "+1+1", fuzz = 0) %>%
  image_annotate(text = "© Mapbox © OpenStreetMap", gravity = "southeast", color = "green", size = 30, location = "+30+20") %>%
  image_write(here("estaciones_3-ciudades_aa.png"))




#- ahora con las carreteras -------------------------------------------------------

roads <- map(cities_data, "road")
# bind_rows doesn't work on sf objects
# so a little workaround
# geoms <- map(roads, st_geometry) %>% reduce(c)
# fields <- map(roads, st_drop_geometry) %>% bind_rows( .id = "city")
# roads <- st_sf(fields, geoms)

maps <- imap(roads, ~ ggplot() + geom_sf(data = filter(.x, class %in% c("major_rail", "minor_rail")), aes(colour = type), show.legend = "line") +
  annotate("text", -Inf, Inf, label = toupper(.y), hjust = 0, vjust = 1, colour = "white", alpha = 0.6, size = 8) +
  guides(color = guide_legend(title = NULL, ncol = 3)) +
  ggthemes::scale_color_tableau() +
theme_void() +
  theme(panel.background = element_rect(fill = "black"), plot.margin = margin(0, 2, 0, 2), legend.position = c(0.1, 0),
    legend.background = element_rect(fill = NA), legend.direction = "horizontal", legend.justification = c(0.1, 0.1),
    legend.text = element_text(colour = "white")
  ))

wrap_plots(maps)
ggsave("rail.png", width = 10, height = 6)

