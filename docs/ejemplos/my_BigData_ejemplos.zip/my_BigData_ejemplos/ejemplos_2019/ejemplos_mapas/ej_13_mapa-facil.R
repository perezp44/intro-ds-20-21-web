#- #ggplot2 mappers, are you still using the map_data() function? Be alerted to @rOpenSci 's fabulous rnaturalearth package. Optionally returns sf & includes a bunch of other useful data
# https://gist.github.com/arvi1000/01b2f3c471651f335db066611addf275

library(rnaturalearth)
library(tidyverse)

world <- ne_countries(scale = "medium", returnclass = "sf")

world %>%
  filter(continent == 'Asia') %>%
  ggplot() +
  geom_sf(aes(fill=income_grp), color='#A98743', size=0.1) +
  # vandergrinten
  coord_sf(crs = '+proj=vandg +lon_0=0 +x_0=0 +y_0=0 +R_A +datum=WGS84 +units=m +no_defs ', datum = NA) +
  theme(plot.background = element_rect(fill = '#EEEBD3'),
        legend.background = element_blank(),
        panel.background = element_blank()) +
  labs(fill = 'Income Group') +
  scale_fill_brewer(palette = 5)
