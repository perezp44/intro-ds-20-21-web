#- Good grafico con las bombillas de una ciudad solo 10 lineas: @ejvankesteren: All lampposts in #utrecht using #rstats #ggplot2. Hooray for #opendata! Full-resolution image & code (only 14 lines!):
#https://gist.github.com/vankesteren/838249095f181f0b70c277a8b2673ec0 https://twitter.com/ejvankesteren/status/1087784059089108993/photo/1


library(tidyverse)

lights_dat <- read_csv("https://ckan.dataplatform.nl/dataset/83402c68-1c05-4aa5-ab28-2e99d2bc2261/resource/dc10e0ac-351a-49b6-b3db-d0152c29dc02/download/paal-20180906.csv")

pp <- lights_dat %>%
  filter(latitude > 50) %>%
  ggplot(aes(x = longitude, y = latitude)) +
  geom_point(alpha = 0.03, fill = "#FAFAAB", stroke = 0, pch = 21, size = 1.6) +
  geom_point(alpha = 0.8,  fill = "#FAFAAB", stroke = 0, pch = 21, size = 0.2) +
  coord_map() +
  theme_void()
#- ggsave("lantaarnpaal.png", bg = "black", width = 10, height = 10, dpi = 300)
