#- ejemplo: Fallas de valencia: prueba esto: CCAA_wgs84  <- CCAA %>% st_transform("+proj=longlat +datum=WGS84")


library(tidyverse) # metapackage with lots of helpful functions
library(rio)

#- los datos están aquí:
#- http://gobiernoabierto.valencia.es/va/resource/?ds=monumentos-falleros&id=0f5ae692-19a9-40b9-919d-746b40c8befa
#- http://mapas.valencia.es/lanzadera/opendata/Monumentos_falleros/CSV

#fallas <- rio::import("./datos/opendata3048275121685062178CSV.csv")
fallas <- read_delim("http://mapas.valencia.es/lanzadera/opendata/Monumentos_falleros/CSV", delim = ";")
fallas <- read_delim("http://mapas.valencia.es/lanzadera/opendata/Monumentos_falleros/CSV", delim = ";", locale = readr::locale(encoding = "latin1"))

names(fallas)

#- tiene la long/lat en las v. X-Y

#- FJG
fallas_sf <- fallas %>% sf::st_as_sf(coords = c("Y", "X"), crs = 25830)
fallas_sf_ok <- st_transform(fallas_sf, crs = "+proj=longlat +datum=WGS84")
#- FJG 2
fallas_sf <- fallas %>% sf::st_as_sf(coords = c("Y", "X"), crs = "+proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs")
fallas_sf_ok <- st_transform(fallas_sf, crs = 25830)


fallas_sf <- fallas %>% sf::st_as_sf(coords = c("Y", "X"), crs = "+proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs")
fallas_sf_ok <- st_transform(fallas_sf, crs = "+proj=longlat +ellps=GRS80 +no_defs")
fallas_sf_ok_ok <- st_transform(fallas_sf_ok, crs = 4326)

#- world2 <- st_transform(world, "+proj=laea +y_0=0 +lon_0=155 +lat_0=-90 +ellps=WGS84 +no_defs")

fallas_sf <- fallas %>% sf::st_as_sf(coords = c("Y", "X"), crs = "+proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs")

#"+proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs"
#- EPGS: 25830

fallas_sf <- fallas %>% sf::st_as_sf(coords = c("Y", "X"), # columns with geometry
               crs = 4326) # WGS84 is a sensible default.
fallas_sf_a <- fallas_sf %>% st_transform("+proj=utm +zone=30 +ellps=GRS80 +units=m +no_defs")




lplot <- leaflet::leaflet(data = fallas_sf_ok) %>% # create leaflet object
  leaflet::addTiles() %>% # add basemap
  leaflet::addMarkers() # add data layer - markers

lplot #  ...

