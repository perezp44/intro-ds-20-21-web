#- Obtener cines y puentes de Valencia
#- geolocalizacion con tmaptools
#- help(package = "tmaptools")

library(tmaptools)

aa   <- geocode_OSM("Valencia")
aa_1 <- geocode_OSM("Valencia", details = TRUE, as.data.frame = TRUE, as.sf = TRUE)


#-Accessing OpenStreetMap data with R: https://dominicroye.github.io/en/2018/accessing-openstreetmap-data-with-r/

#load packages
library(tidyverse)
library(osmdata)
library(sf)
library(leaflet)
library(ggmap)


aa <- available_features() %>% as.data.frame()



q <- getbb("Valencia") %>% #- Get bounding box
     opq() %>%             #- Build an Overpass query
       add_osm_feature("amenity", "cinema") #- Add a feature to an Overpass query

cinema <- osmdata_sf(q)  #-


# nos bajamos el background map
mad_map <- get_map(getbb("Valencia"), maptype = "toner-background")

# ggmap map
p <- ggmap(mad_map) + geom_sf(data = cinema$osm_points, inherit.aes = FALSE,
                         colour ="#238443", fill ="#004529", alpha = .5, size = 4, shape = 21) +
                      labs(x = "", y = "")
p
# leaflet map
lplot <- leaflet::leaflet(data = cinema$osm_points) %>% # create leaflet object
  leaflet::addTiles() %>% # add basemap
  leaflet::addMarkers() # add data layer - markers

lplot

#- los PUENTES de Valencia ------------------------------------------------------------------
q <- getbb("Valencia") %>% #- Get bounding box
     opq() %>%             #- Build an Overpass query
       add_osm_feature("bridge") #- Add a feature to an Overpass query
bridge <- osmdata_sf(q)  #-

bridge

#ggmap map
p <- ggmap(mad_map) + geom_sf(data = bridge$osm_points, inherit.aes = FALSE,
                         colour ="#238443", fill ="#004529", alpha = .5, size = 4, shape = 21) +
                      labs(x = "", y = "")


# leaflet map
lplot <- leaflet::leaflet(data = bridge$osm_points) %>% # create leaflet object
  leaflet::addTiles() %>% # add basemap
  leaflet::addMarkers() # add data layer - markers



#- el carril BICI ----------------------------------------------------- no me salio!!!

q <- opq(bbox = "Valencia", timeout = 600)
q1 <- add_osm_feature(q, key = 'highway', value = "cycleway")
x <- osmdata_sp(q1)
plot(x$osm_lines)

library(leaflet)

# leaflet map
lplot <- leaflet::leaflet(data = x$osm_lines) %>% # create leaflet object
  leaflet::addTiles() %>% # add basemap
  leaflet::addPolygons(color = "purple", weight = 116) # add data layer - markers
lplot


