#- se baja una pagina web y coge y manipula una tabla
#- https://www.brodrigues.co/blog/2018-12-15-lubridate_africa/
library(tidyverse)
library(rvest)
library(lubridate)

page <- read_html("https://en.wikipedia.org/wiki/Decolonisation_of_Africa")

independence <- page %>%
    html_node(".wikitable") %>%
    html_table(fill = TRUE)

independence <- independence %>%
    select(-Rank) %>%
    map_df(~str_remove_all(., "\\[.*\\]")) %>%
    rename(country = `Country[a]`,
           colonial_name = `Colonial name`,
           colonial_power = `Colonial power[b]`,
           independence_date = `Independence date[c]`,
           first_head_of_state = `First head of state[d]`,
           independence_won_through = `Independence won through`)


independence <- independence %>%
  mutate(independence_date = dmy(independence_date))


independence %>%
  filter(year(independence_date) <= 1960) %>%
  pull(country)


independence %>%
  filter(month(independence_date) == 12,
         day(independence_date) == 24) %>%
  pull(country)

independence %>%
  mutate(today = lubridate::today()) %>%
  mutate(independent_since = interval(independence_date, today)) %>%
  select(country, independent_since)


independence %>%
  mutate(today = lubridate::today()) %>%
  mutate(independent_since = interval(independence_date, today)) %>%
  select(country, independent_since) %>%
  mutate(years_independent = as.numeric(independent_since, "years"))

