#- Objetivo: descargar datos OCDE desde R. Utilizaremos el pkg "OECD"
#- web de la OCDE: http://stats.oecd.org/
library(OECD)   #- pkg OEDE: https://github.com/expersso/OECD
library(tidyverse) 

# usando OECD pkg -------------------------- 


# Busquedas
dataset_list <- get_datasets()  #- df con listado de datos disponibles (1.238)
aa <- search_dataset("education") #- busqueda de datos sobre "education" (28)

# Descarga de datos: EAG_MOB, AVD_DUR, ICT_HH2
my_st <- "EAG_MOB"
df <- get_dataset(my_st)  #- descarga de la tabla EAG_MOB (9.538 x 11)

# Informacion sobre los datos descargados
browse_metadata(my_st)  #- informacion en la web OCDE
aa <- get_data_structure(my_st)  #- informacion sobre codigos etc....returns a list of dataframes with human-readable values for variable names and values. The first data frame contains the variable names and shows the dimensions of a dataset
str(aa, max.level = 1)
str(aa)
aa1 <- aa[[1]] #- listado de variables
aa_x <- aa[[3]] #- niveles educativos (ISC11A)
bb <- val_unicos_df_pjp(df) #- los valores decada variable

#- filtramos datos con dplyr:: AGE = [25-64], L0T2 = Below upper secondary education, PARED1 = Neither parent has attained upper secondary
df_a <- df %>% filter(SEX == "T", AGE == "Y25T64", ISC11A == "L0T2", 
                      PIAAC_CATEGORY == "PARED1", MEASURE == "VALUE", obsTime == "2012") #- 25 observaciones



# turn variable names to lowercase
names(df_a) <- names(df_a) %>% tolower()    #- good


