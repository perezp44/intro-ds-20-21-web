#- objetivo: aprender a manejar datos con dplyr
#- datos INE del padron 2017 (nacionalidad, municipios y genero)
options(scipen = 999) #- para quitar la notacion científica

library(tidyverse)
library(pxR)
library(personal.pjp)

df_orig <- read.px("./datos/pob_padron.px") %>% as.data.frame %>% as.tbl

#- veamos que variables hay
aa <- names_v_df_pjp(df_orig)
bb <- val_unicos_df_pjp(df_orig)

#--- Renombro las v.
df_orig <- df_orig %>% set_names(c("nacionalidad", "municipios", "sexo", "value")) #- renombro

#--- arreglo
df_orig <- df_orig %>% map_if(is.factor, as.character) %>% as_tibble()      #- los factores los paso a caracteres (igual con los graficos tendre q volver a factores)
df_orig <- df_orig %>% map(str_trim, side = "both") %>% as.tibble()         #- quita caracteres al final y al ppio (no me fio un pelo)
df_orig <- df_orig %>% mutate(value = as.integer(value))                    #- lo paso a integers

#--- arreglo (manias!!)
df_orig <- df_orig %>% mutate(nacionalidad = if_else(nacionalidad == "Españoles", "Espanoles", nacionalidad))
df_orig <- df_orig %>% mutate(nacionalidad = if_else(nacionalidad == "Total Población", "Total_Poblacion", nacionalidad))
df_orig <- df_orig %>% mutate(nacionalidad = if_else(str_detect(nacionalidad, "^(Total )") , str_replace(nacionalidad,"Total ","Total_"), nacionalidad))
df_orig <- df_orig %>% mutate(sexo = if_else(sexo == "Ambos sexos", "Ambos_sexos", sexo))

#- veamos como ha quedado el df original
aa <- names_v_df_pjp(df_orig)
bb <- val_unicos_df_pjp(df_orig)


#- PRIMERO nos centramos en el agregado de ESP: hay un municipio llamado "Total"
#-- vamos a ver que nacionalidad es mayoritaria en ESP
#- primero poblacion total (Toda ESP) la grabo  en df
df <- df_orig %>% filter(municipios == "Total") %>% select(-municipios)
aa <- names_v_df_pjp(df)
bb <- val_unicos_df_pjp(df)

#- calculo porcentajes sobre poblacion total
df <- df %>% group_by(sexo) %>% dplyr::mutate(percent = value/max(value))


#- tenemos los datos en long format. Es el mas adecuado para trabajar con el tidyverse, PERO quiero ponerlo como si fuese una tabla para ver cada municipio en una row
feo <- df %>% select(nacionalidad, sexo, percent) %>% spread(sexo, percent)
feo1 <- df %>% select(nacionalidad, sexo, value) %>% spread(sexo, value)
df_a <- right_join(feo, feo1, by = "nacionalidad", suffix = c("_percent", "_value")) %>% arrange(desc(Ambos_sexos_percent))
df_a <- decimales_df_pjp(df_a, n = 4)    #- arreglamos los decimales

rm(feo, feo1) #- ya no hacen falta
head(df_a, n = 8) #- vemos que la nacionalidad mas numerosa en España es la marroqui, un 1,61%

#- veamos si lso estranjeros son principalmente hombres o mujeres
df_a <- df_a %>% mutate(propor_H = Hombres_value/Ambos_sexos_value) %>% arrange(desc(propor_H))
head(df_a) #- vemos que el 77,8% de los senegales en España son hombre
tail(df_a)        #- por contra los paraguayos en Españo son mayoritariamente mujeres, solo un 28,8% de ellos son hombres




#- OK , ahora se trataria de repetir el analisi para ver  en que municipio hay mayor porcentaje de cada una de las nacionalidades
#- Lo tenia hecho, PERO no lo he arreglado aqui. Lo dejo x si algun dia lo hago
#- municipios -------------------------------------------
#- municipios -------------------------------------------
df <- df_orig %>% filter(municipios != "Total") %>% separate(municipios, into = c("INECodMuni", "NombreMuni"), sep = "-" , extra = "merge")


#- quito los totales de las nacionalidades

df_totales <- df %>% filter(str_detect(nacionalidad, "^(Total)|Espanoles|Ocean") )
df_totales <- df_totales %>% spread(nacionalidad, value) %>% select(1:3, 12,4,11, everything())

#- quito los totales de las nacionalidades
df_paises <- df %>% filter( !(str_detect(nacionalidad, "^(Total)|Espanoles|Ocean") ) )
df_paises <- df_paises %>%  spread(nacionalidad, value)

#aa <- df_paises %>% summarise_if(is.numeric,sum)

df_ok <- left_join(df_totales, df_paises, by = c("INECodMuni", "NombreMuni", "sexo"))

df_ok <- df_ok %>% mutate(ahora = Total_Poblacion)


# df_ok2 <- df_ok %>% mutate_at(vars(4:11), funs(.[]/.$`Total Población`))
# df_ok2 <- df_ok %>% mutate_at(vars(Total Población:Alemania), funs(./`Total Población`))
# df_ok2 <- df_ok %>% mutate_at(vars(5), funs(./`Total Población`))
# df_ok2 <- df_ok %>% mutate_if( is.numeric, funs(./`Total Población`))
# df_ok2 <- df_ok %>% mutate_if( is.integer, funs(./Alemania))   #-- OK

df_ok2 <- df_ok %>% mutate_if( is.integer, funs(./ahora))   #-- OK

df_ok3 <- df_ok2 %>% filter(sexo == "Ambos_sexos")



#Ahora querría ver (para cada nacionalidad) cual es el pueblo donde mas % representa esa nacionalidad del total de ese pueblo.


df_ok4 <- df_ok3 %>% summarise_if( is.numeric, funs(max(., na.rm = TRUE))) #- SI, tengo el maximo % de cada nacionalidad



#ahora quiero ver cada pueblo que nacionalidad es mas importante


df_ok5 <- df_ok3 %>% select(-c(sexo, ahora)) %>% gather(nacion, value, 3:40) %>% ungroup()


feo <- df_ok5 %>% filter(!str_detect(nacion, "^(Total_)|Espanoles|Ocean"))

feo1 <- feo  %>% group_by(INECodMuni)  %>%
  dplyr::mutate(maxim = max(value)) %>% dplyr::mutate(cual = nacion[which.max(value)]) #- AQUI

feo2 <- feo1 %>% select(-c(nacion, value)) %>% unique()   #-- GOOD

feo3 <- feo2 %>% group_by(cual) %>% dplyr::summarise(NN = n())

usar <- feo2 %>% filter(maxim != 0)
usar2 <- usar %>% group_by(cual) %>% dplyr::summarise(NN = n())


#Ver en que provincias estan los municipios

muni <- cod_muni_pjp_17
aver <- left_join(muni, usar,  by = "INECodMuni") %>%
  select(5, 6, 7, 8, 12, 13, 14 )
aver2 <- aver %>% filter(maxim > 0.05)





```{r}
#BB <- AA %>% st_set_geometry( NULL)  #- quita la geometria
library(sf)
library(tmap)
library(spanishRshapes)
library(viridisLite)
library(leaflet)
```


#### Ahora mapa municipios

```{r}
shapes_mun <- IGN_mun_17s #- cargo shape files (8211 recontos)
shapes_mun <- shapes_mun %>% filter(!str_detect(INECodMuni, "^53|^66")  ) #- quito condominios y 6 islitas
shapes_mun <- shapes_mun %>% select(INECodMuni)

MMM <- left_join(shapes_mun, aver2,  by = "INECodMuni")
class(MMM)


pais_vasco <- tm_shape(MMM, alpha = 0.3) +
  tm_fill(col = "cual",  title = "Percent", colorNA = "white") +
  tm_polygons(border.alpha = 0.6) +
  tm_layout(legend.position = c("left", "bottom"))
```








