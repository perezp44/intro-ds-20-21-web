#- http://slides.com/hafen/trelliscopejs-sdss2018#/

#install.packages("trelliscopejs")
library(tidyverse)
library(trelliscopejs)

pokemon <- read_csv("http://bit.ly/plot_pokemon") %>%
  mutate_at(vars(matches("_id$")), as.character) %>%
  mutate(panel = img_panel(url_image))


trelliscope(pokemon, name = "pokemon", nrow = 3, ncol = 6, state = list(labels = c("pokemon", "pokedex")))

#- en lugar de pokemones, que sean países
library(gapminder)
qplot(year, lifeExp, data = gapminder) +
  theme_bw() +
  facet_trelliscope(~ country + continent,
    name = "gapminder_lifeexp",
    desc = "life expectancy vs. year by country",
    nrow = 2, ncol = 7,
    width = 300)
