# Objetivo: datasaurus. https://github.com/lockedata/datasauRus

#install.packages("datasauRus") #- https://github.com/lockedata/datasauRus
library(datasauRus)
library(ggplot2)


#--------------------------------------
df_wide <- datasaurus_dozen_wide
df <- datasaurus_dozen

ggplot(df, aes(x=x, y=y, colour=dataset)) +
  geom_point() +
  theme_void() +
  theme(legend.position = "none") +
  facet_wrap(~dataset, ncol=3)
