#- ejemplo tutorial_0: bajada del Quijote y wordcloud

#- https://cran.r-project.org/web/packages/gutenbergr/  #- pkg. gutenbergr en CRAN
#- http://github.com/ropenscilabs/gutenbergr            #- en Github
#- https://cran.r-project.org/web/packages/gutenbergr/gutenbergr.pdf         #- Reference Manual en CRAN
#- https://cran.r-project.org/web/packages/gutenbergr/vignettes/intro.html   #- vignette




#- longuitud frases Quijote: https://analisisydecision.es/longitud-de-las-frases-del-quijote-con-rstats/. Puedes combinarlo con udipe q saca adjetivos etc… https://bnosac.github.io/udpipe/docs/doc5.html

# install.packages("gutenbergr")
library("gutenbergr")
library("tidyverse")

df <- gutenberg_metadata  #- "bajamos" un listado de obras en el proyecto Gutenberg.org

df_eng <- gutenberg_works()   #- listado de obras en inglés, por defecto languages = "en"
df_eng_esp <- gutenberg_works(languages = c("en", "es"))   #- en ingles y español
df_cast <- gutenberg_works(languages = "es")  #- listado de obras en español

df_cervantes <- df_cast %>% filter(author == "Cervantes Saavedra, Miguel de")   #- obras de Cervantes

#----------------------------- regular expressions (para buscar mejor en texto)
library("stringr")
df_cervantes <- df_cast  %>% filter(str_detect(author, "Cervantes"))
df_valencia <- df  %>% filter(str_detect(title, "Valencia"))





#------ nos bajamos el texto del Quijote
id_Platero <- "9980"
id_Quijote <- "2000"


Quijote <- gutenberg_download(gutenberg_id = id_Quijote, meta_fields = c("title", "author"))


#- Ok, ya tenemos el Quijote, pero no se muestran bien las tildes y las ñ (problema de encoding)
#- Lo solucionamos de 6 formas. Según como vaya el curso lo veremos o no.

Quijote_ok <- Quijote

#---- with a loop
for (i in seq_along(Quijote$text)) {
  Quijote_ok$text[i]  <-  iconv( Quijote$text[i], from = "latin1", to = "UTF-8")
}

#---- with apply
Quijote_ok$text <- apply(Quijote[,"text"], 1, function(.) iconv( ., from = "latin1", to = "UTF-8" ) )

Quijote_ok <- lapply(Quijote[,"text"], function(.) iconv( ., from = "latin1", to = "UTF-8" ) ) %>% as.tibble()

Quijote_ok <- lapply(Quijote, function(.) iconv( ., from = "latin1", to = "UTF-8" ) ) %>% as.tibble()


#---- with purr
Quijote_ok$text <- Quijote$text %>% map_chr( iconv , from = "latin1", to = "UTF-8")

Quijote_ok <- Quijote %>% map( iconv , from = "latin1", to = "UTF-8") %>% as.tibble()



#- BIEN!! ya tenemos el texto del Quijote. Ahora hagamos un WORD CLOUD
# http://blog.fellstat.com/?cat=11
# https://www.r-bloggers.com/text-mining-and-word-cloud-fundamentals-in-r-5-simple-steps-you-should-know/
#----------------
library(syuzhet)
library(tm)
library(wordcloud)
#---------------
Quijote_ok_copy <- Quijote_ok
Quijote_ok <- Quijote_ok %>% slice(1:1000)  #- para q no tarde mucho solo cogemos las 1000 primeras lineas del Quijote

corpus <- as.vector(paste(Quijote_ok$text, collapse = ' '))
corpus <- tolower(corpus)  #- a minusculas


docs <- Corpus(VectorSource(corpus)) %>%              #- construye un corpus
  tm_map(removePunctuation) %>%                       #- quita los signos de puntuacion
  tm_map(removeNumbers) %>%                           #- quita los numeros
  tm_map(removeWords, stopwords("spanish")) %>%       #- quita "palabras-vacias"
  tm_map(stripWhitespace) %>%                         #- quita espacios
  tm_map(PlainTextDocument)

tdm <- TermDocumentMatrix(docs) %>%   as.matrix()
wf <- sort(rowSums(tdm),decreasing=TRUE)             #- conteo de palabras en orden decreciente

dm <- data.frame(word = names(wf), freq = wf) #- crea un df con las palabras y sus frecuencias

dm <- dm %>% arrange(desc(freq))
dm2 <- dm %>% slice(1:50)

wordcloud(dm2$word, dm2$freq, random.order=FALSE, colors = brewer.pal(8, "Dark2"))


#------https://www.r-bloggers.com/the-wordcloud2-library/
library(wordcloud2)
letterCloud( dm2, word = "R", color = 'random-light' , backgroundColor = "black")
wordcloud2(dm, color = "random-light", backgroundColor = "grey")




# corpus = tm_map(corpus, removeWords, c(stopwords("spanish"), "camila_vallejo"))  #- quita "palabras vacias"

