#- https://www.mzes.uni-mannheim.de/socialsciencedatalab/article/studying-politics-wikipedia/
#- usa Wikidat y wikipedia, hay aplicaciones interactivas
library(tidyverse)
library(WikipediR)  #- An R API wrapper for MediaWiki, optimised for the Wikimedia Foundation MediaWiki instances, such as Wikipedia.
library(WikidataR)  #- An R API wrapper for the Wikidata store of semantic data.
library(pageviews)  #- An API client library for Wikimedia traffic data: https://github.com/ironholds/pageviews
library(lubridate)
#- pageviews:
# get pageviews
trump_views <-
  article_pageviews(
    project = "en.wikipedia",
    article = "Donald Trump",
    user_type = "user",
    start = "2015070100",
    end = "2017050100"
  )
head(trump_views)

clinton_views <-
  article_pageviews(
    project = "en.wikipedia",
    article = "Hillary Clinton",
    user_type = "user",
    start = "2015070100",
    end = "2017050100"
  )

# Plot pageviews
plot(ymd(trump_views$date), trump_views$views, col = "red", type = "l", xlab="Time", ylab="Pageviews")
lines(ymd(clinton_views$date), clinton_views$views, col = "blue")
legend("topleft", legend=c("Trump","Clinton"), cex=.8,col=c("red","blue"), lty=1)
