#- script para generar a bunch of parametrised reports
#- para ello tenemos que utilizar la función: rmarkdown::render()

library(tidyverse)

#- vamos a crear un informe (Valencia en 2017) ---------------------------------

rmarkdown::render(
  input = here::here("ej_parametrised-Rmds", "my_parametrised_report.Rmd"), 
  params = list(municipio = "Valencia", periodo = 2017),
  output_file = here::here("ej_parametrised-Rmds", "informes-automaticos", "Valencia-en-2017.html"))
}





#- vamos a crear un conjunto de informes
#- haremos el informe para un conjunto de municipios (pero para un solo periodo, p.ej: año 2010)
municipios <- c("Valencia", "Alzira")


#- é de poner en el YAML: `r my_HEADER`  (no hace falta)

for (ii in 1:length(municipios)) {
  my_MUNICIPIO <- municipios[ii]
  my_HEADER <- glue::glue("Informe para ", {my_MUNICIPIO} , " (Año 2010)")
  #---
  rmarkdown::render(
    input = here::here("ej_parametrised-Rmds", "my_parametrised_report.Rmd"), 
    params = list(municipio = my_MUNICIPIO, periodo = 2010),
    output_file = here::here("ej_parametrised-Rmds", "informes-automaticos", municipios[ii]))
  }
          
        

#- ahora lo hacemos tb para varios periodos -------------------------------
municipios <- c("Valencia", "Alzira")
anyitos <- c(2010, 2017)


for (ii in 1:length(municipios)) {
  my_MUN <- municipios[ii]
  
    for (jj in 1:length(anyitos)) {
      my_ANY <- anyitos[jj]
      my_HEADER <- glue::glue("Informe para ", {my_MUN} , " (Año ", {my_ANY}, ")")
      my_titulo_informe <- paste0(my_MUN, "-", my_ANY)
      #------
      
      rmarkdown::render(
            input = here::here("ej_parametrised-Rmds", "my_parametrised_report.Rmd"), 
            params = list(municipio = my_MUN, periodo = my_ANY),
            output_file = here::here("ej_parametrised-Rmds", "informes-automaticos", my_titulo_informe) ) 
  }
}
          
          


#- voy a generar el nombre de los informes
# zz <- expand.grid(municipios, anyitos) 
# zzz <- zz %>% tidyr::unite(new_col, Var1, Var2, sep = "_") %>% pull()
# nombres_de_los_informes <- paste0("./informes-automaticos/", zzz)
# matriz_nombres <- matrix(data = nombres_de_los_informes, nrow = 2, ncol = 2)