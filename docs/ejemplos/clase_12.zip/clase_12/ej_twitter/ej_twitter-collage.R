#- ejemplo twitter collage: 
#- https://www.jtimm.net/2020/01/05/2020-01-01a-year-in-twitter-photos/

library(rtweet)
library(tidyverse)

#- cuenta de Twitter elegida
my_person <- "NachoVegasTwit" #- @NachoVegasTwit

NV_tweets <- rtweet::get_timeline(my_person, n = 1500, check = FALSE) 
#rio::export(NV_tweets, "./datos/tweets_NV_7.rds")
#NV_tweets <- rio::import("./datos/tweets_NV_7.rds")


aa <- NV_tweets %>%
  mutate(created_at = as.Date(gsub(' .*$', '', created_at))) %>%
  filter(is_quote == 'FALSE' & 
           is_retweet == 'FALSE' & 
           created_at > '2019-01-02' &
           display_text_width > 0)


pics <- aa %>%
  filter(!is.na(media_url)) %>%
  select(media_url, created_at)

#setwd(local_pics)


my_fun_pics <- function (y) {
    magick::image_read(y) %>%
    magick::image_scale("1000") %>%
    magick::image_border('white', '10x10') %>%
    magick::image_write(path = here::here("afotos",   gsub('^.*/', '', y)) )#%>%
  #magick::image_annotate(pics$created_at[y], font = 'Times', size = 50)
}
  
# my_pic <- "http://pbs.twimg.com/media/EoIiWQQXUAAKhF5.jpg"
# my_fun_pics(my_pic)

#lapply(pics$media_url, function (y) {
map(pics$media_url, my_fun_pics)
  

files <- fs::dir_ls("./afotos/")
files <- dir("afotos", full.names = TRUE)
set.seed(11)
files <- sample(files, length(files))

files1 <- files[1:49]
no_rows <- 7
no_cols <- 7

make_column <- function(i, files, no_rows){
  magick::image_read(files[(i*no_rows+1):((i+1)*no_rows)]) %>%
    magick::image_append(stack = TRUE) %>%
    magick::image_write(here::here("afotos", "columnas", paste0("cols", i, ".jpg")))}

#- hace columnas de 7 a fotos
purrr::walk(0:(no_cols-1), make_column,  files = files1,
     no_rows = no_rows)



#- stack the columns-----------------------
magick::image_read(dir("afotos/columnas/", full.names = TRUE)) %>% 
  magick::image_scale("500x1000") %>%
  magick::image_append(stack = FALSE) %>% 
  magick::image_write(here::here("my_collage.jpg"))

