Trabajo para la asignatura “Big Data”
-------------------------------------

Repo utilizado para elaborar el trabajo para la asignatura “Programación
y manejo de datos en la era del Big Data” de la Universitat de València
durante el curso 2020-2021. La página web de la asignatura puede verse
aquí:
<a href="https://perezp44.github.io/intro-ds-20-21-web/" class="uri">https://perezp44.github.io/intro-ds-20-21-web/</a>.

El documento con el código para hacer mi trabajo se encuentra en el
archivo `index.Rmd` del repo. La versión final del trabajo puede
visualizarse en:
<a href="https://perezp44.github.io/trabajo_BigData/" class="uri">https://perezp44.github.io/trabajo_BigData/</a>.

El trabajo trata de /consiste en ….
