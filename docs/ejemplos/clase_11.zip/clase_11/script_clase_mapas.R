#- script para clase_10 de BigData 20-21 (mapas) -------------------------------

library(tidyverse)
library(patchwork)
library(ggrepel)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(ggspatial)
library(pjpv2020.01)  #- remotes::install_github("perezp44/pjpv2020.01")

#- cargo los datos previamente guardados --------------------------------------
load("./datos/geometrias_clase_10.RData")


#---------------------------------------
p1 <- ggplot(CCAA,  aes(fill = INECodCCAA) ) + 
  geom_sf() +
  scale_fill_viridis_d(guide = FALSE) +   # theme(legend.position = "none")
  labs(title = "Coord. geográficas")

p2 <- ggplot(CCAA,  aes(fill = INECodCCAA) ) + 
  geom_sf() + coord_sf(crs = 2154, datum = sf::st_crs(2154)) +
  scale_fill_viridis_d(guide = FALSE) +
  labs(title = "Lambert 93")

p1 + p2


#- elegimos 4 CC.AA ------------------------------------------------------------
zz_prov_chosen <- c("Andalucía", "Galicia", "Aragón", "Canarias", "Illes Balears")

zz_prov_1 <- Provincias %>% filter(NombreCCAA %in% zz_prov_chosen)
zz_prov_2 <- Provincias %>% filter(!(NombreCCAA %in% zz_prov_chosen))

p1 <- ggplot(zz_prov_1, aes(fill = INECodProv) ) + 
  geom_sf()  +
  scale_fill_viridis_d(guide = FALSE) +
  labs(title = "Coord. geográficas")

p2 <- ggplot(zz_prov_2, aes(fill = INECodProv) ) + 
  geom_sf()  +
  scale_fill_viridis_d(guide = FALSE) +
  labs(title = "Coord. geográficas")

p1 + p2 

CCAA

#- creamos las geometrías de las CC.AA por agrupación de las geometrías provinciales ------
CCAA_2 <- Provincias %>% group_by(INECodCCAA, NombreCCAA) %>% summarize()

p1 <- ggplot(Provincias, aes(fill = INECodProv) ) + 
  geom_sf()  +
  scale_fill_viridis_d(guide = FALSE) +
  labs(title = "Coord. geográficas")


p2 <- ggplot(CCAA_2, aes(fill = INECodCCAA) ) + 
  geom_sf()  +
  scale_fill_discrete(guide = FALSE) +
  labs(title = "Coord. geográficas")

p1 + p2 


# WORLD ------------------------------------------------------------------------
#world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf")
class(world) #- es un sf, pero tb es un data.frame
names(world) #- fijate que la ultima columna se llama geometry y almacena los datos espaciales

#- de momento haremos los mapas con ggplot2
ggplot(data = world) + geom_sf()

ggplot(data = world, aes(geometry = geometry)) + geom_sf()

ggplot() + geom_sf(data = world, aes(geometry = geometry))

#- los mapas se pueden tunear à la ggplot
ggplot(data = world) + geom_sf(color = "black", fill = "lightgreen", lwd = 0.2)

p <- ggplot(data = world) + geom_sf() +
      labs(title = "Gráfico 1: Mapa del mundo",
      caption = "Datos provenientes de rnaturalearth")
p


#- COROPLETAS: graficamos una variable estadística (muchas veces discreta)
p + geom_sf(aes(fill = pop_est))
p + geom_sf(aes(fill = pop_est)) + scale_fill_distiller()
p + geom_sf(aes(fill = pop_est)) + scale_fill_viridis_c(option = "plasma", trans = "sqrt")


#- PROYECCIONES
#- world2 <- st_transform(world, "+proj=laea +y_0=0 +lon_0=155 +lat_0=-90 +ellps=WGS84 +no_defs")
p + coord_sf(crs = "+proj=laea +y_0=0 +lon_0=155 +lat_0=-90 +ellps=WGS84 +no_defs") + 
  labs(subtitle = "Lambert Azimuthal Equal Area projection")


p + coord_sf(crs = "+proj=laea +lat_0=52 +lon_0=10 +x_0=4321000 +y_0=3210000 +ellps=GRS80 +units=m +no_defs ")  #- usamos PROJ string

p + coord_sf(crs = st_crs(3035))   #- usamos SRID identifier

p + coord_sf(crs = "+init=epsg:3035")  #- usamos EPSG code (mejor no usarlo xq GDAL ha deprecated esta sintaxis)



#- Hacemos ZOOM ----------------------------------------------------------------
p_esp <- p + coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = FALSE)
p_esp

#- ponemos elementos de mapas (estrela y guía)
p_esp + 
  ggspatial::annotation_scale(location = "bl", width_hint = 0.5) +
  ggspatial::annotation_north_arrow(location = "bl", which_north = "true", 
                                    pad_x = unit(0.75, "in"), pad_y = unit(0.5, "in"),
                                    style = north_arrow_fancy_orienteering)


#- TEXTO en el mapa: centroides ------------------------------------------------
world_points <- st_centroid(world)    #- sustituye la geometry por el centroide
world_points <- cbind(world, st_coordinates(st_centroid(world$geometry))) #- ahora el centroide pasa a estar en 2 columnas, llamadas X e Y, donde figuran la longitud y latitud del centroide

#- truco para ver mejor los datos espaciales: quitar la geometría
names(world_points)
zz <- world_points %>% select(name, iso_a3,  X, Y) %>%  
  st_set_geometry(NULL)  #- por si quiero ver mejor los datos del df

#- mapa con texto en los centroides
p_esp + 
  geom_text(data = world_points, 
            aes(x = X, y = Y, label = name), 
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) +
  annotate(geom = "text", x = 5.5, y = 38, 
           label = "Mar Mediterráneo", fontface = "italic", color = "grey22", size = 4)

#- quitamos a Francia del df de centroides (world_points) y repetimos el gráfico 
world_points <- world_points %>% filter(admin != "France")


#- tuneemos/mejoremos el gráfico del munco
p + 
  geom_sf(fill = "antiquewhite") +
  geom_text(data = world_points, 
            aes(x = X, y = Y, label = name), 
            color = "darkblue", fontface = "bold", 
            check_overlap = TRUE, size = 2) +
  annotation_north_arrow(location = "bl", which_north = "true",
                         pad_x = unit(0.75, "in"), 
                         pad_y = unit(0.5, "in"),
                         style = north_arrow_fancy_orienteering) +
  theme(panel.grid.major = element_line(color = gray(.5), linetype = "dashed", size = 0.5), 
        panel.background = element_rect(fill = "aliceblue"))
p


#- Otra vez ZOOM
p + coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = FALSE) +
  ggspatial::annotation_scale(location = "bl", width_hint = 0.5)

#- si quisieramos guardarlo
# gsave("map.pdf")
# ggsave("map_web.png", width = 6, height = 6, dpi = "screen")


#- Mas TUNEADO -----------------------------------------------------------------

#- añadiendo puntos
pueblos <- data.frame(
  nombre = c("Pancrudo", "Valencia"), 
  longitude = c(-1.028781, -0.3756572),
  latitude = c(40.76175, 39.47534) )     
pueblos

p_esp + 
  geom_point(data = pueblos, 
             aes(x = longitude, y = latitude), 
             size = 2, color = "darkred") +
  geom_text(data = pueblos, 
            aes(x = longitude, y = latitude, label = nombre), 
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5)

#- convertimos un df a un spatial df con st_as_sf()
pueblos_sf <- st_as_sf(pueblos, 
                       coords = c("longitude", "latitude"), 
                       crs = 4326,  #- EPSG:4326 Coordenadas Geográficas WGS84
                       agr = "constant")

p_esp + geom_sf(data = pueblos_sf, size = 2, color = "darkred")

#- hemos perdido el zoom
p_esp + geom_sf(data = pueblos_sf, size = 2, color = "darkred") + 
coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = FALSE)


#- Añadiendo POLIGONOS ---------------------------------------------------------
zz_CCAA <- CCAA %>% st_set_geometry(NULL)
p + geom_sf(data = CCAA, fill = NA) + 
  coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = FALSE)


#- Añadimos las provincias de Andalucia pero coloreadas por población
INE_padron_muni_96_19 <- pjpv2020.01::pjp_data_pob_mun_1996_2019

pob_andalucia <- INE_padron_muni_96_19 %>% 
  filter(year == 2017) %>% 
  filter(poblacion == "Total") %>% 
  filter(INECodCCAA.n == "Andalucía") %>%
  group_by(INECodProv.n) %>% mutate(n_pueblos = n_distinct(INECodMuni.n)) %>%
  mutate(pob_prov = sum(pob_values, na.rm = TRUE)) %>% ungroup() %>%
  mutate(pob_media_pueblos = pob_prov/n_pueblos) %>% 
  select(INECodProv.n, INECodProv, pob_media_pueblos, pob_prov, n_pueblos) %>%
  distinct() %>% ungroup()

# Provincias <- Provincias
zz_Provincias <- Provincias %>% st_set_geometry(NULL)

#- juntamos geometrias de Provincias con poblacion
geo_pob_andalucia <- left_join(pob_andalucia, Provincias, by = c("INECodProv" = "INECodProv"))
geo_pob_andalucia <- left_join(pob_andalucia, Provincias)


p + geom_sf(data = CCAA, fill = NA) +
  geom_sf(data = geo_pob_andalucia, aes(geometry = geometry, fill = n_pueblos)) +
  scale_fill_viridis_c(alpha = .4) +
  geom_sf(data = pueblos_sf, size = 2, color = "darkred") +
  coord_sf(xlim = c(-15.00, 25.00), ylim = c(21, 57.44), expand = FALSE)


#- añadimos 3 municipios al azar, bueno, no tan al azar
IGN_nomencla_muni <- rio::import("https://github.com/perezp44/spanishRentidadesIGN/blob/master/data/IGN_nomencla_muni.rda?raw=true")

pueblos_3 <- IGN_nomencla_muni %>% 
  filter(NOMBRE_ACTUAL %in% c("Pancrudo", "Alburquerque", "Polentinos")) %>% 
  select(NOMBRE_ACTUAL, PROVINCIA, LONGITUD_ETRS89, LATITUD_ETRS89) %>%
  st_as_sf(coords = c("LONGITUD_ETRS89", "LATITUD_ETRS89"), crs = 4326, agr = "constant", remove = FALSE)


p_esp <- p + geom_sf(data = CCAA, fill = NA) +
  geom_sf(data = geo_pob_andalucia, aes(geometry = geometry, fill = n_pueblos)) +
  scale_fill_viridis_c(alpha = .4) +
  geom_sf(data = pueblos_3, size = 2, color = "darkred") +
  ggrepel::geom_label_repel(data = pueblos_3, aes(x = LONGITUD_ETRS89, y = LATITUD_ETRS89, label = NOMBRE_ACTUAL)) +
  coord_sf(xlim = c(-10.00, 7.00), ylim = c(35, 45), expand = FALSE)
p_esp


#- CANARIAS: Con los mapas y gráficos nunca se acaba!!! ------------------------
canarias <- Provincias %>% filter(INECodProv %in% c(35,38))
peninsula <- Provincias %>% filter( !(INECodProv %in% c(35, 38)) )

my_shift <- st_bbox(peninsula)[c(1,2)]- (st_bbox(canarias)[c(1,2)]) + c(-2.4, -1.1)

canarias$geometry <- canarias$geometry + my_shift
st_crs(canarias)  <- st_crs(peninsula)
peninsula_y_canarias <- rbind(peninsula, canarias)

p1 <- ggplot() + geom_sf(data = peninsula_y_canarias)
p2 <- ggplot() + geom_sf(data = peninsula) + geom_sf(data = canarias, fill = "purple") 
#coord_sf(xlim = c(-12.00, 4.00), ylim = c(33, 44), expand = FALSE)

p1 + p2 

ggplot() + geom_sf(data = peninsula) +
  geom_sf(data = canarias) +
  coord_sf(xlim = c(-12.00, 4.00), ylim = c(33, 44), expand = FALSE)

#- Canarias en rojo -
p_esp + geom_sf(data = canarias, fill = "red") +
  coord_sf(xlim = c(-12.00, 5.00), ylim = c(30, 44), expand = FALSE)


#- el rio Ebro
#rios <- rio::import("https://github.com/perezp44/archivos_download/blob/master/rio_ebro.rds?raw=true")
zz_rios <- rios %>% st_set_geometry(NULL)
names(rios)

#- no hace falta pero
cod_rios_guenos <- c(913757, 913687, 913685, 913619)
nombre_rios_guenos <- c("Pancrudo", "Jiloca", "Jalón", "Ebro")

rios_guenos <- rios %>% filter(Cod_Uni %in% cod_rios_guenos)

ggplot(data = peninsula) + geom_sf() +
  geom_sf(data = rios_guenos, color = "lightblue", lwd = 1.3) +
  labs(subtitle = "Mapa de España con 4 ríos Güenos", color = "")


#- ¿Cómo se llama el río pequeñín?
ggplot(data = peninsula) + geom_sf() +
  geom_sf(data = rios_guenos, color = "lightblue", lwd = 1.3) +
  geom_point(data = pueblos, aes(x = longitude, y = latitude), size = 2, color = "darkred") +
  geom_text(data = pueblos, aes(x = longitude, y = latitude, label = nombre), color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) + 
  labs(subtitle = "Mapa de España con 4 ríos Güenos", color = "")
# col = sf::sf.colors(2, alpha = 0.5)



# MAPVIEW

pueblos <- data.frame(nombre = c("Pancrudo", "Valencia"), longitude = c(-1.028781, -0.3756572), latitude = c(40.76175, 39.47534)) #- ETRS89

pueblos_sf <- st_as_sf(pueblos, coords = c("longitude", "latitude"), crs = 4326, agr = "constant") #- EPSG:4326 Coordenadas Geográficas WGS84
mapview::mapview(pueblos_sf)


mapview::mapview(rios)


INE_padron_muni_96_19 <- pjpv2020.01::pjp_data_pob_mun_1996_2019
info_CCAAs <- INE_padron_muni_96_19 %>% 
  filter(year == 2017) %>% 
  filter(poblacion == "Total") %>% 
  group_by(INECodCCAA.n) %>% 
  mutate(n_prov = n_distinct(INECodProv)) %>% 
  mutate(n_pueblos = n_distinct(INECodMuni)) %>% 
  mutate(pob_CCAA = sum(pob_values, na.rm = TRUE)) %>% ungroup() %>%
  select(INECodCCAA, INECodCCAA.n, n_prov, n_pueblos, pob_CCAA) %>%
  distinct() %>% ungroup()


CCAA_con_info <- left_join(CCAA, info_CCAAs,  by = c("INECodCCAA" = "INECodCCAA"))


mapview::mapview(CCAA_con_info, 
                 zcol = c("NombreCCAA", "n_prov", "n_pueblos", "pob_CCAA"),
                 color = "tomato", col.regions = "purple", lwd = 3,
                 cex = "n_pueblos")
mapview::mapview(CCAA_con_info, 
                 zcol = c("NombreCCAA", "n_prov", "n_pueblos", "pob_CCAA"),
                 cex = "n_pueblos")


mapview::mapview(list(CCAA_con_info, pueblos_sf), layer.name = c("CC.AA", "2 municipios chachis"))


mapview::mapview(CCAA_con_info, zcol = c("NombreCCAA", "n_prov", "n_pueblos", "pob_CCAA")) +
  mapview::mapview(pueblos_sf) 


#install.packages("mapedit")
library(mapedit)
my_map <- mapview::mapview(pueblos_sf)
drawFeatures(my_map, editor = "leafpm")   #- good


#- Leaflet ------------------------------------
library(leaflet)
leaflet() %>% addTiles() %>% leafem::addMouseCoordinates()

m <- leaflet() %>%
  addTiles() %>% 
  setView(lng = -1.0287810, lat = 40.76175, zoom = 6) %>% 
  addMarkers(lng = -1.0287810, lat = 40.76175, popup = "Pancrudo") %>% 
  addPopups(lng = -0.3756572, lat = 39.47534, popup = "Valencia")
m





m <- leaflet() %>%
  addTiles() %>% 
  setView(lng = -1.0287810, lat = 40.76175, zoom = 6) %>% 
  addMarkers(lng = -1.0287810, lat = 40.76175, popup = "Pancrudo") %>% 
  addPopups(lng = -0.3756572, lat = 39.47534, popup = "Valencia")
m



leaflet(data = CCAA) %>% addTiles() %>%
  addPolygons(fillColor = topo.colors(18, alpha = NULL), stroke = FALSE)



#- Operaciones gemetricas ------------------------------
Provicias_5 <- Provincias %>% 
  mutate(area = st_area(.)) %>% 
  mutate(areakm2 = units::set_units(area, km^2)) %>% 
  arrange(desc(areakm2)) %>% 
  slice(1:5)
ggplot() + geom_sf(data = Provincias) + geom_sf(data = Provicias_5, fill = "purple")




Prov_5_centroides <- st_centroid(Provicias_5) 
Prov_5_centroides <-  cbind(Prov_5_centroides, st_coordinates(st_centroid(Prov_5_centroides$geometry)))

ggplot() + geom_sf(data = Provincias) + 
  geom_sf(data = Provicias_5, fill = "purple") +
  geom_text(data = Prov_5_centroides, 
            aes(x = X, y = Y, label = NombreProv),
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) +
  labs(title = "Las 5 provincias españolas más extensas", x = "", y = "") 


#- distancias a Pancrudo  --------------
Prov_centroides <- st_centroid(Provincias) 
Prov_centroides_XY <- cbind(Prov_centroides, st_coordinates(st_centroid(Prov_centroides$geometry)))
distancias <- st_distance(Prov_centroides_XY, by_element = FALSE) #- devuelve una matriz



municipios_sf <- st_as_sf(municipios_2017, coords = c("LONGITUD_ETRS89", "LATITUD_ETRS89"), crs = st_crs(4258))


pancrudo_sf <- municipios_sf %>% slice(6694)
g1 <- st_geometry(municipios_sf)
g1_pancrudo <- st_geometry(pancrudo_sf) #- dejo solo la geometria

#- distancias_a_Pancrudo <- mapply(st_distance, g1, g1_pancrudo) %>% as.vector) #- con R-base
distancias_a_Pancrudo <- map2(g1, g1_pancrudo, st_distance) %>% as_vector()         #- con purrr
distancias_a_Pancrudo <- as.data.frame(distancias_a_Pancrudo)
df_con_distancias_a_Pancrudo <- bind_cols(municipios_sf, distancias_a_Pancrudo) %>% 
  mutate(Kms = distancias_a_Pancrudo * 100) %>% 
  arrange(Kms)



#- Municipios por los que pasa el río Ebro ---------

muni_xx <- municipios_2017 %>% st_set_geometry(NULL)
muni    <- municipios_2017

#zz <- muni_xx %>% group_by(INECodCCAA, NombreCCAA) %>% count()
muni_borrar <- c("Illes Balears", "Canarias")
muni <- muni %>% filter(!(NombreCCAA %in% muni_borrar))

rios <- read_rds(here::here("datos",  "mapas", "Rios", "rio_ebro.rds"))


rios <- read_rds(here::here("datos",  "mapas", "Rios", "rio_ebro.rds"))


theme_set(cowplot::theme_map())
p <- ggplot(muni) + 
  geom_sf(color = "grey", fill = "white", lwd = 0.01) +
  geom_sf(data = rios_x, color = "lightblue", lwd = 1.6) +
  geom_point(data = pueblos, aes(x = longitude, y = latitude), size = 3, color = "darkred") +
  geom_text(data  = pueblos, aes(x = longitude, y = latitude, label = nombre), color = "darkred",
            fontface = "bold", check_overlap = TRUE, size = 2.5) +
  labs(title = "R-Mapa con 4 ríos güenos",
       caption = "Datos provenientes del paquete LAU2boundaries4spain") +  
  theme(panel.background = element_rect(fill = "aliceblue"))
p