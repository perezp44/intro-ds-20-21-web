#- https://www.mzes.uni-mannheim.de/socialsciencedatalab/article/studying-politics-wikipedia/

#library(WikipediR)  #- An R API wrapper for MediaWiki, optimised for the Wikimedia Foundation MediaWiki instances, such as Wikipedia.
#library(WikidataR)  #- An R API wrapper for the Wikidata store of semantic data.
library(pageviews)   #- An API client library for Wikimedia traffic data: https://github.com/ironholds/pageviews
library(tidyverse)

#- pageviews:
R_views <- article_pageviews(project = "en.wikipedia", article = "R (programming language)", user_type = "user",
                             start = "2015070100", end = "2019113000")
R_views_es <- article_pageviews(project = "es.wikipedia", article = "R (lenguaje de programación)", user_type = "user",vstart = "2015070100", end = "2019113000")

Phyton_views <- article_pageviews(project = "en.wikipedia", article = "Python (programming language)", user_type = "user", start = "2015070100", end = "2019113000")

Phyton_views_es <- article_pageviews(project = "es.wikipedia", article = "Python", user_type = "user",  start = "2015070100", end = "2019113000")
zz <- R_views


str(R_views)

#- agrupamos visitas por meses
library(lubridate)

R_views <- R_views %>% group_by(month = floor_date(date, "month")) %>% summarize(views_R = sum(views))
R_views_es <- R_views_es %>% group_by(month = floor_date(date, "month")) %>% summarize(views_R_es = sum(views))
Phyton_views <- Phyton_views %>% group_by(month = floor_date(date, "month")) %>% summarize(views_Phyton = sum(views))
Phyton_views_es <- Phyton_views_es %>% group_by(month = floor_date(date, "month")) %>% summarize(views_Phyton_es = sum(views))

#- podriamos haberlo hecho con una función (o más facil con una pipe chain)
my_pipes <- . %>% group_by(month = floor_date(date, "month")) %>% summarize(views = sum(views))

my_pipes(zz)
zz %>% my_pipes

#- pongamos las 4 series juntas
df <- bind_cols(R_views, R_views_es, Phyton_views, Phyton_views_es)

df <- bind_cols(R_views, R_views_es, Phyton_views, Phyton_views_es) %>% select(-c(month1, month2, month3))

df <- full_join(R_views, R_views_es) %>% full_join(Phyton_views) %>% full_join(Phyton_views_es)

#- veamos si España es +R q los English
df <- df %>% mutate(R_phy = views_R / views_Phyton) %>%
             mutate(R_phy_es = views_R_es / views_Phyton_es)

#- Hagamos un gráfico con las 4 series para ver su evolución... OK, pero .... ¿los datos están en formato TIDY? NO


#- estan en formato tidy?? NO. Pues habrá q hacerlo TIDY **trabajo en clase**



#- ahora ya sí, un gráfico con las 4 series  **trabajo en clase**
