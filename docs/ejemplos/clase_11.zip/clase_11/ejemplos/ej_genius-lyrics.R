#- ejemplo: spotify: https://www.harsh17.in/blog/exploring-my-spotify-listening
#- Soptify no lo vamos a hacer xq necesita tener un acces token

#- pero si vamos a conseguir letras con el pkg "genius"
library(genius)
library(tidyverse) # For manipulation

my_album <- genius_album(artist = "Nacho Vegas", album = "Actos inexplicables")

my_song <- genius_lyrics(artist = "Nacho Vegas", song = "El Angel Simon", info = "simple")

track_list <- genius_tracklist(artist = "Nacho Vegas", album = "Actos inexplicables") 


# https://www.hvitfeldt.me/2018/04/ggpage-version-0-2-0-showcase/   (para el Quijote)


#- word cloud ----------------------------------------------
library(tidytext)
library(stringr)
library(wordcloud2)
library(tm)  #- stopwords("spanish")


#Unnest the words - code via Tidy Text
my_tabla_con_words <- my_song %>% unnest_tokens(word, lyric)

#remove stop words - aka typically very common words such as "the", "of" etc
esp_stop <- stopwords("spanish") %>% as.data.frame() 
names(esp_stop) <- "word"

my_tabla_con_words <- my_tabla_con_words %>% anti_join(esp_stop)     # quita las stop_words


#do a word count
my_tabla_con_words <- my_tabla_con_words %>% count(word, sort = TRUE) 

#Remove other nonsense words
my_tabla_con_words <- my_tabla_con_words %>%
  filter(!word %in% c('t.co', 'https', 'handmaidstale', "handmaid's", 'season', 'episode', 'de', 'handmaidsonhulu',  'tvtime', 'watched', 'watching', 'watch', 'la', "it's", 'el', 'en', 'tv', 'je', 'ep', 'week', 'amp'))

wordcloud2(my_tabla_con_words, size = 0.7)
