#- poner una imagen en un polígono: https://coolbutuseless.github.io/2020/11/18/demo-rendering-images-in-polygons-with-ggplot2-and-ggpattern/
library(tidyverse)
library(ggpattern)  #- remotes::install_github("coolbutuseless/ggpattern")

load("./datos/geometrias_clase_10.RData")

peninsula <- CCAA %>% filter(!(NombreCCAA %in% c("Canarias")))

Aragon <- CCAA %>% filter(NombreCCAA %in% c("Aragón", "Extremadura"))


ggplot() + geom_sf(data = peninsula) +
  geom_sf_pattern(data = Aragon, pattern = 'placeholder', pattern_type = 'kitten') +
  theme_bw() + 
  labs(title = "En Aragón nos gustan los gatos")

#- https://coolbutuseless.github.io/package/ggpattern/articles/pattern-image.html
#- https://coolbutuseless.github.io/package/ggpattern/reference/fill_area_with_img.html
ggplot() + geom_sf(data = peninsula) +
  geom_sf_pattern(data = Aragon, 
                  pattern = 'image', 
                  pattern_filename = "./imagenes/bart_simpson_chalkboard-5157.jpg")
            
#- un ejemplo de uso chulo: https://twitter.com/dickoah/status/1333506738386038784 
