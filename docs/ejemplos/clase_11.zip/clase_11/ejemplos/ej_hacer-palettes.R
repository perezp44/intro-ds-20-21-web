#- https://github.com/zumbov2/colorfindr
#- install.packages("colorfindr")

#- Un ejemplo: https://github.com/annahensch/R-tutorials/blob/master/ggplot-on-fire.md

# Load packages
pacman::p_load(colorfindr, tidyverse)

#- imagen a usar
url <- "https://upload.wikimedia.org/wikipedia/commons/a/af/Flag_of_South_Africa.svg"

# get & plot colors
get_colors(img = url , min_share = 0.05) %>% plot_colors(sort = "size")


#- make palette
my_paleta <- get_colors(img = url, min_share = 0.05) %>%  make_palette(n = 6) # here we extract 6 colors
my_paleta

#- usar la paleta
library(palmerpenguins) # get the penguin data
p <- penguins %>% 
     ggplot(aes(flipper_length_mm, fill = species)) + 
        geom_density(alpha = 0.8, color = NA) 

p

p + scale_fill_manual(values = my_paleta)




# Get colors and create a palette (n = 5) with foto de Tintín 
get_colors("https://www.movieart.ch/bilder_xl/tintin-et-milou-poster-11438_0_xl.jpg") %>% 
  make_palette(n = 5)



# Plot (5000 randomly selected pixels)
colorines <- get_colors("https://upload.wikimedia.org/wikipedia/commons/f/f4/The_Scream.jpg")
colorines %>% plot_colors_3d(sample_size = 5000, marker_size = 2.5, color_space = "RGB")


