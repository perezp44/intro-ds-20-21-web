#- piramide de poblacion
#- https://gist.github.com/ikashnitsky/6e59b91db406ef366e115373d2d77873
#===============================================================================
# 2020-10-19 -- twitter
# Turkey population pyramid 1960
# Ilya Kashnitsky, ilya.kashnitsky@gmail.com
#===============================================================================

library(tidyverse)
library(magrittr)
library(hrbrthemes)
options(scipen = 999)

theme_set(
  theme_minimal(base_family = font_rc, base_size = 14)+
    theme(
      legend.position = "none",
      panel.grid.minor = element_blank(),
      line = element_line(lineend = "round")
    )
)

# download eurostat data
library(eurostat)

my_table <- "demo_pjan"         #- "Population on 1 January by age, sex and NUTS 2 region"
label_eurostat_tables(my_table)    #- gives information about the table

eu_pop <- get_eurostat("demo_pjan")


df <- eu_pop %>% 
  # clean the dataset
  filter(
    !age %in% c("TOTAL", "UNK")
  ) %>% 
  mutate(
    year = time %>% lubridate::year(),
    age = age %>% 
      paste %>% 
      str_replace("Y_LT1", "Y_0") %>% 
      str_replace("Y_OPEN", "100") %>% 
      str_remove("_") %>%  
      str_remove("Y") %>% 
      as.numeric()
  ) %>% 
  arrange(time, sex, age) %>% 
  transmute(
    id = geo,
    year,
    sex = sex %>% as_factor() %>% 
      lvls_revalue(c("f", "m", "b")),
    age,
    value = values
  ) %>% 
  # plot Turkey 1960 age pyramid
  filter(
    !sex == "b", ! age == 100, id == "TR", year == 1960
  ) %>% 
  mutate(value = case_when(sex=="m" ~ -value, TRUE ~ value)) 



p <- df %>% 
  ggplot(aes(value, age, color = sex)) +
  geom_vline(xintercept = 0, size = 1, color = "#bababa") +
  geom_path() +
  #geom_col(aes(x = value , y = age)) +
  #geom_bar(aes(x = value ,  y = age), stat = "identity") +
    scale_x_comma(
    breaks = seq(-4e5, 4e5, 2e5), 
    labels = seq(-4e5, 4e5, 2e5) %>%  abs
  )+
  scale_color_manual(values = c(2, 5))+ 
  annotate(
    "text", label = c("Males", "Females"),
    x = c(-3e5, 3e5), y = 75, 
    size = 7, family = font_rc, color = c(5, 2)
  )+
  labs(
    title = "Turkey, 1960",
    caption = "Data: Eurostat (demo_pjan) | @ikashnitsky",
    x = NULL
  )+
  theme(plot.title = element_text(family = "Roboto Slab"))

p

#- ggsave("~/Downloads/turkey-1960-pyramid.png", width = 5, height = 4)
#- otras pirámides: piramides de población: https://kjhealy.github.io/uscenpops/

