#- objetivo: para aquellos que no tengan tema, este es un tema "facil"

library(tidyverse)
library(eurostat)
library(sf)

#------------------ searching data about a topic (health) in Eurostat API with search_eurostat()
aa <- search_eurostat("Health", type = "all")

#------------------ select some data from Eurostat
#my_table <- "hlth_silc_17"          #- we select "hlth_silc_17": "Healthy life expectancy based on self-perceived health"
#my_table <- "hlth_rs_prshp1"        #- seleccioné la tabla: "Health personnel employed in hospital"
my_table <- "hlth_rs_grd"        #- seleccioné la tabla: "Health graduates"

label_eurostat_tables(my_table)     #- gives information about the table



#------------------ dowloading the selected data with get_eurostat()
df <- get_eurostat(my_table, time_format = 'raw', keepFlags = TRUE)       #- dowloads the table from Eurostat API
#df_l <- label_eurostat(df, fix_duplicated = TRUE)                        #- gives labels for the variables
df_names <- names(df)
df <- label_eurostat(df, code = df_names, fix_duplicated = TRUE)
rm(aa,  df_names, my_table)
#zz <- df %>% filter(stringr::str_starts(geo, "ES")) %>% filter(time == 2019) %>% filter(age == "Y1")


#- veamos un poco los datos
df_bb <- pjpv2020.01::pjp_f_unique_values(df, truncate = TRUE, nn_truncate = 200)

#- y me quedo con lo que me interesa analizar
df_ok <- df %>% 
    filter(isco08 == "Medical doctors") %>%  #- Medical doctors
    filter(unit_code == "P_HTHAB")  %>%      #- Per hundred thousand inhabitants
    select(geo_code, geo, time, values) %>% 
    mutate(time = as.numeric(time))          #- mas adelante (igual) nos hará falta q sea numerico y no character

#- como las coropletas se ven mejor con variables categóricas:
#- Las cloropetas suelen quedar mejor si discretizamos la variable a graficar
#- podriamos hacerlo con ntile() pero eurostat::cut_to_classes() te pone un nombre para la categoria muy adecuado
#- Categorisng the values with cut_to_classes()
#- Es posible que tus datos permitan categorizar para diferentes categorias. por ejemplo sex o edad etc....

df_ok <- df_ok %>% group_by(time) %>%        
  mutate(cat_time  = cut_to_classes(values, n = 4, decimals = 1, style = "quantile")) %>%
  mutate(cat_time_1 = as.factor(ntile(values, n = 4))) %>% ungroup()


#- dowloading the geometries for European countries
geometrias <- get_eurostat_geospatial(resolution = "20", nuts_level = "0")
plot(geometrias, max.plot = 1)

#-  merging the data with the geometries
mapdata <- inner_join(df_ok, geometrias, by = c("geo_code" = "id"))

#- selecciono lo q quiero graficar: 2019 (paree que los datos de 2019 no están todavía)
#- en 2018 no hay datos para Francia (!!!) asi que cojo 2017
mapdata_si <- mapdata %>%  filter(time == 2017)



p <- ggplot(mapdata_si) +
  geom_sf(aes(fill = cat_time,  geometry = geometry), color = "black", size = .1) +
  scale_fill_brewer(palette = "RdYlBu") +
  labs(title = "Graduados en medicina (2017)",
       subtitle = "(por cada 100.000 habitantes)",
       fill = "Médicos por 100.000 hab",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12,44), ylim = c(35,67))


p

#- Una mejora fácil es hacer un facet ---------------
#- fijate que cojo los datos de varios (4 años)
#- fijate q ahora uso cat_time_1

p <- mapdata %>% 
     filter(time %in% c(1980, 1990, 2000, 2010, 2017)) %>% 
  ggplot() +
  geom_sf(aes(fill = cat_time_1,  geometry = geometry), color = "black", size = .1) +
  scale_fill_brewer(palette = "RdYlBu") + 
  labs(title = "Graduados en medicina (2018)",
       subtitle = "(por cada 100.000 habitantes)",
       fill = "Médicos por 100.000 hab",
       caption = "(C) EuroGeographics for the administrative boundaries") + theme_light() +
  coord_sf(xlim = c(-12,44), ylim = c(35,67))


p + facet_wrap(vars(time)) #-
