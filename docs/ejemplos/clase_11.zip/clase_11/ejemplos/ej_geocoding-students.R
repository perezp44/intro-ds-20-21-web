#- tidygeocoder: https://github.com/ikashnitsky/dataviz-mpidr/blob/master/day5/geocoding.R
#- geolocalizar el lugar de nacimiento de la gente de la clase

library(tidyverse)
library(tidygeocoder)
library(mapview)
library(leafpop)


df <- rio::import("./datos/answers-cuestionario-inicial.xlsx")

df <- df %>% janitor::clean_names()  #- limpio los nombres
df <- df %>% tidyr::drop_na()        #- quito los NA's: bueno en realidad no hay NA's

df <- df %>% mutate(text_to_geocode = paste(ciudad, pais, sep = ", "))

# now geocode -----
library(tidygeocoder)
df <- df %>% tidygeocoder::geocode(text_to_geocode, method = "osm") %>% select(- text_to_geocode)

# convert coordinates to an sf object
library(sf)
df <- df %>% st_as_sf(coords = c("long", "lat"), crs = 4326)

#- lo guardamos per si de cas
# rio::export(df, "./datos/df_estud-geolocalizados.rds")
# df <- rio::import("./datos/df_estud-geolocalizados.rds")

# graficamos con mapview: https://r-spatial.github.io/mapview/index.html -------------------------
mapview::mapview(df)

#- calculamos el nº de gente que nació en el mismo lugar
df <- df %>% group_by(ciudad, pais) %>% mutate(NN_lugar = n()) %>% ungroup()
mapview::mapview(df, cex = "NN_lugar")

#- se puede tunera el gráfico (pero a mi no me ha funcionado bien)
library(leafpop)
mapview::mapview(df, popup = popupTable(df, zcol = c("nombre", "apellidos", "ciudad")))


# graficamos con leaflet: https://rstudio.github.io/leaflet/  ------------------------------------

library(leaflet)
leaflet() %>% addTiles() %>% leafem::addMouseCoordinates()


leaflet(data = df) %>% addTiles() %>%
    addMarkers( popup = ~as.character(link), label = ~as.character(nombre))

#- venga, vamos a hacerlo un poco mejor (espero)
