#- ejemplo Wikidata: https://cran.r-project.org/web/packages/wikifacts/wikifacts.pdf
#- ejemplo: Wiidata: https://twitter.com/Wikimedia_mx/status/1332207421230632961

library(tidyverse)
library(wikifacts) 
  

#Largest cities of the world: https://twitter.com/Wikimedia_mx/status/1332207421230632961
# https://query.wikidata.org/#%23Largest%20cities%20of%20the%20world%0ASELECT%20DISTINCT%20%3FcityLabel%20%3Fpopulation%20%3Fgps%0AWHERE%0A%7B%0A%20%20%3Fcity%20wdt%3AP31%2Fwdt%3AP279*%20wd%3AQ515%20.%0A%20%20%3Fcity%20wdt%3AP1082%20%3Fpopulation%20.%0A%20%20%3Fcity%20wdt%3AP625%20%3Fgps%20.%0A%20%20SERVICE%20wikibase%3Alabel%20%7B%0A%20%20%20%20bd%3AserviceParam%20wikibase%3Alanguage%20%22es%22%20.%0A%20%20%7D%0A%7D%0AORDER%20BY%20DESC(%3Fpopulation)%20LIMIT%20100

query <- 
'SELECT DISTINCT ?cityLabel ?population ?gps
WHERE
{
  ?city wdt:P31/wdt:P279* wd:Q515 .
  ?city wdt:P1082 ?population .
  ?city wdt:P625 ?gps .
  SERVICE wikibase:label {
    bd:serviceParam wikibase:language "es" .
  }
}
ORDER BY DESC(?population) LIMIT 100'

df <- wiki_query(query)

#- hay q arreglar la columa gps
df <- df %>% mutate(gps = stringr::str_remove(gps, "Point\\(" ))
df <- df %>% mutate(gps = stringr::str_remove(gps, "\\)" ))
df <- df %>% tidyr::separate(gps, into = c("long", "lat"), sep = " ")


# convert coordinates to an sf object
library(sf)
df <- df %>% st_as_sf(coords = c("long", "lat"), crs = 4326)

library(leaflet)
leaflet(data = df) %>% addTiles() %>%
  addMarkers( popup = ~as.character(population), label = ~as.character(cityLabel))
