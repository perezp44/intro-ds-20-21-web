#- https://blog.ephorie.de/create-bart-simpson-blackboard-memes-with-rlibrary(meme)

url <- "http://free-extras.com/pics/b/bart_simpson_chalkboard-5157.gif"
url <- here::here("imagenes", "bart_simpson_chalkboard-5157.gif")

meme::meme(url, font = "Comic Sans MS", upper = "No actualicéis!! \n No actualices \n siempre sesión LIMPIA!!")
