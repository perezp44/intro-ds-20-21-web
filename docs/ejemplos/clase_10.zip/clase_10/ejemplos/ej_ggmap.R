#- seguramente no os funcionará xq hace falta estar registrado en las APIs de Google
#- https://github.com/dkahle/ggmap
#- https://www.datanalytics.com/libro_r/introduccion-a-ggmap.html
library(ggmap)

#- geolocalización
UV_adress <- ggmap::geocode("Avenida de los Naranjos,  Facultat de Economía, Valencia, España", 
                         source = "google")

#- geolocalización inversa
revgeocode(as.numeric(UV_adress))

#- devuelve un "mapa"
map.UV_adress <- ggmap::get_map(location = as.numeric(UV_adress),
                      color = "color",
                      maptype = "roadmap",
                      scale = 2, zoom = 16)

#- graficamos el mapa
ggmap(map.UV_adress) + geom_point(aes(x = lon, y = lat),
                               data = UV_adress, colour = 'red',
                               size = 4)


#- una ruta
mapa <- get_map("Valencia, España", source = "stamen", maptype = "toner", zoom = 12)
ggmap(mapa)
ruta <- route(from = "Facultad de Economia, valencia", to = "Playa Malvarrosa, Valencia")

#- no chuta
ggmap(mapa) + 
  geom_path(aes(x = startLon, y = startLat, xend = endLon, yend = endLat),
            colour = "red", size = 2, data = ruta)
