#- ejemplo: hacer un inset plot con patchwork: https://www.data-imaginist.com/2020/insetting-a-new-patchwork-version/
#- Un ejemplo: https://cmdlinetips.com/2020/11/insetting-with-patchwork/
library(tidyverse)
library(patchwork)


p1 <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point() +
  labs(title = "Gráfico 1: Longitud del sépalo frente al pétalo",
       subtitle = "(Inset: Densidades de la longitud del sépalo)")

p2 <- ggplot(iris, aes(Sepal.Length, fill = Species)) + 
      geom_density(position = "stack", alpha = 0.5) + 
    labs(title = "Gráfico 2: Densidades estimadas  \n de la longitud del sépalo)",
       subtitle = "(Para cada especie de lirio)")


p1 + inset_element(p2, left = 0.6, right = 0.99, bottom = 0.01, top = 0.45)


#ggsave("plot_con_insetting-patchwork.png", width = 9,height = 8)