#- ENTREGA nº 08 (para hacer en casa)
#- Deadline para la entrega: Jueves a las 23:59
#---- Pon tus datos de identificación ------------------------------------------
#- Apellidos: 
#- Nombre: 
#- e-mail: 
#- NPA: 
#-------------------------------------------------------------------------------
#- Sólo has de entregar el fichero .R 
#- El fichero se ha de llamar: entrega-08-44P5566X-perez-pedro.R
#- no hay que comprimirlo!!!!!
#-------------------------------------------------------------------------------
#- Objetivo: asentar los conocimientos de ggplot2. 
#- Antes bajaremos datos del Banco Mundial con el paquete "wbstats": https://github.com/nset-ornl/wbstats
#-------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------------
library(tidyverse)  
library(wbstats)   #- remotes::install_github("nset-ornl/wbstats")

#- wbstats facilita ver que datos tiene el World Bank, porque tiene almacenada esa información en un objeto, concretamente en la lista "wb_cachelist"

lista_codigos <- wbstats::wb_cachelist #- nos traemos "wb_cachelist" al Global environment
str(lista_codigos, max.level = 1 )     #- vemos con str(), la estructura de la lista "lista_codigos"

#- veamos más en detalle que información tiene el World Bank
lista_countries  <- lista_codigos[[1]]  #- R-base:con el operador [[xx]] podemos seleccionar el elemento xx de la lista
lista_indicators <- lista_codigos[[2]]


#- aprovechamos este post: https://github.com/keithmcnulty/hans_rosling_bubble/blob/master/rosling.R
#- para bajarnos datos anuales (1960-2019) de todos los países de 3 indicadores similares a los que tiene el pkg "gapminder":
#- SP.DYN.LE00.IN:	Life expectancy at birth, total (years)
#- NY.GDP.PCAP.CD:	GDP per capita (current US$)
#- SP.POP.TOTL   :	Population, total


#- bajamos los datos del World Bank con la f. wb_data() del pkg "wbstats"
datos <- wbstats::wb_data(indicator = c("SP.DYN.LE00.IN", "NY.GDP.PCAP.CD", "SP.POP.TOTL"), 
                       country = "countries_only", start_date = 1960, end_date = 2019) 

#- arreglo los nombres de los indicadores para que sean mas intuitivos
datos <- datos %>% 
         rename(esperanza_vida = SP.DYN.LE00.IN) %>% 
         rename(PIB_percapita = NY.GDP.PCAP.CD) %>% 
         rename(poblacion = SP.POP.TOTL) 
 

#- como veis, si comparamos con los datos de gapminder, nos falta la variable continente. 
#- Tenemos una v. parecida a continent en el df lista_countries: concretamente tenemos la variable "region"
zz <- lista_countries %>% distinct(region) #- fijaros que el World Bank agrupa los paises en 8 regiones

#- vamos a añadir la region al df "datos" ¿cómo? juntando las tablas con left_join() 
zz <- lista_countries %>% select(iso3c, region, region_iso3c)
datos <- left_join(datos, zz, by = c("iso3c" = "iso3c")) #- juntamos las 2 tablas
datos <- datos %>% select(-iso2c)       #- quito la variable iso2c que sobra


#- OK, finalmente vamos a trabajar con el data.frame "datos", así que voy a borrar los demás objetos de la memoria de R. Pero antes a datos "lo voy a llamar df" para trabajar mas cómodo:
df <- datos
rm(list = setdiff(ls(), "df"))   #- borra todos los objetos en el Global, excepto df

#- Como bajarse los datos de la web del World Bank cuesta un ratito, casi merece la pena guardar df por si acaso
#- Lo guardo en formato .rds, con el paquete rio  en   "./datos/"
rio::export(df, here::here("datos", "df.rds"))

#- y así, si tienes que retomar el análisis puedes hacerlo desde aquí:


#- COMIENZA la práctica de GGPLOT2 -------------------------------------------------------------------------------------------
#- COMIENZA la práctica de GGPLOT2 -------------------------------------------------------------------------------------------

library(tidyverse)
df <- rio::import("./datos/df.rds")  #- df tiene 13.020 rows x 8 columnas
str(df)
#- vamos a trabajar SIEMPRE con los datos desde 1980 a 2018:
df <- df %>% mutate(date = as.numeric(date))  #- no hace falta .....
df <- df %>% filter(date >= 1980)             #- quitamos los datos anteriores a 1980

#- veamos un poco los datos (tienes que ver de que tipo son (character o numeric, ...), si tienen NAs, sus valores únicos)
df_aa <- pjpv2020.01::pjp_f_estadisticos_basicos(df)  #- remotes::install_github("perezp44/pjpv2020.01")


#- PREGUNTAS: --------------------------------------------------------------------------------
#- PREGUNTAS: --------------------------------------------------------------------------------

#- Pregunta 1)
#- muestra la evolución en el tiempo de la Esperanza de vida en "Spain" (atención: siempre con datos desde  1980). El eje y que empiece en 0.
#- Pista: mira la sección 3.5 y/o 3.6 del tutorial sobre ggplot2

p <- df %>% filter(country == "Spain") %>% 
  ggplot(aes(x = date, y = esperanza_vida)) +
  geom_point() + 
  geom_line()  
p

p + ylim(0, 90)
p + lims(y = c(0, 90))
p + scale_y_continuous(breaks = seq(0, 90, 10),  limits = c(0, 90))


#- Pregunta 2)
#- Muestra la evolución de la esperanza de vida (recuerda que siempre desde 1980) para los siguientes países:
paises <- c("Spain", "France", "Germany", "Norway", "Portugal", "United States")

zz <- df %>% select(country) %>% distinct()

df_paises <- df %>% filter(country %in% paises)
ggplot(df_paises, aes(x = date, y = esperanza_vida, color = country)) +
     geom_point() + 
      geom_line()


#- Pregunta 3)
#- Haz el mismo gráfico que hemos hecho antes pero que las lineas (y puntos) de todos los países se vean en gris, pero que la linea de España se vea en "orange"
#- Pista: en algún momento tendrás que hacer dentro de aes(...., group = country)

df_esp <- df %>% filter(country == "Spain")

ggplot(df_paises, aes(x = date, y = esperanza_vida, group = country)) +
    geom_line(colour = "grey80") + 
    geom_line(data = df_esp, color = "orange") +
    geom_point(data = df_esp, color = "orange") 


#- Pregunta 4)
#- muestra en un gráfico el país con más esperanza de vida cada año 

#- pista: primero tendrás que calcular/obtener el país con más esperanza de vida cada año
df_top_1 <- df %>% group_by(date) %>% slice_max(esperanza_vida, n = 1) %>% ungroup() %>% arrange(date)

#- pista: aes(x = date, y = esperanza_vida)
#- pista: tb has de usar geom_text()


df_top_1 %>% ggplot(aes(x = date, y = esperanza_vida)) + 
    geom_line(alpha = 0.3) +
    geom_text(aes(label = country), size = 2.25, nudge_y = 0.75) +
    geom_point() +
    scale_x_continuous(breaks = seq(1980, 2018, 5), limits = c(1980, 2018))

#- respuesta de un estudiante:
df_top_1 %>% ggplot(aes(date, esperanza_vida,)) + geom_line(aes(color = country)) +
     geom_point(aes(color = country)) + geom_text(aes(label = country), size = 2.3)


#- Pregunta 5)
#- Con las observaciones de 2017, haz un boxplot para la Esperanza de vida agrupando por "region". Para que el gráfico se vea mejor haz un "coord_flip()" y añade las observaciones individuales, pero en lugar de con geom_point() hazlo con geom_jitter()

df_2017 <- df %>% filter(date == 2017)

p <- ggplot(df_2017, aes(x = region,  y = esperanza_vida)) + 
     geom_boxplot() + coord_flip()
p

p + geom_jitter(width = 0.1, alpha = 1/4, color = "tomato")


#- Pregunta 6)
#- Calcula la población total de cada región para el año 2017 y muéstrala en una gráfico de barras
df_pob <- df %>% filter(date == 2017) %>% 
                 group_by(region) %>% 
                 summarise(Pob_region = sum(poblacion, na.rm = TRUE)) %>% 
                 mutate(Pob_region = Pob_region /1000000) #- población en millones

ggplot(df_pob,  aes(x = region, y = Pob_region)) + 
       geom_col(fill = "steelblue") + 
       coord_flip() +
       labs(title = "Población (millones de habitantes)" )


#- con geom_bar()  Dairo Quintero -----
#- geom_bar() cuenta el nº de filas en cada categoría
ggplot(df_pob,  aes(x = region)) + 
  geom_bar(fill = "steelblue") + 
  coord_flip() +
  labs(title = "Población (millones de habitantes)" )

#- en este caso es mejor usar geom_col() pero se puede forzar a geom_bar()
ggplot(df_pob,  aes(x = region, y = Pob_region)) + 
  geom_bar(stat = "identity", fill = "steelblue") + 
  coord_flip() +
  labs(title = "Población (millones de habitantes)" )

    
# Pregunta 7)
#- haz que las barras del gráfico se ordenen de menor a mayor población
#- Pista: lo tenéis hacia el final de la sección 6.4 del tutorial sobre ggplot2. Lo que pasa es que en lugar de usar forcats::fct_infreq() deberéis usar por ejemplo forcats::fct_reorder()

str(df_pob)  #- la v. region es de tipo character

df_pob <- df_pob %>% mutate(region = forcats::as_factor(region))   #- convertimos la v. region en factor con la f. as_factor()

str(df_pob)  #- la v. region ahora es un factor
levels(df_pob$region) #- los levels del  están ordenador alfabéticamente

df_pob <- df_pob %>% mutate(region = forcats::fct_reorder(region, Pob_region)) #- reordenamos los niveles del factor en f. de Pob_region

levels(df_pob$region) #- ahora los levels del factor estan ordenador en funcion de la población

ggplot(df_pob, aes(x = region, y = Pob_region)) + geom_col(fill = "steelblue") + coord_flip()

ggplot(df_pob, aes(x = Pob_region, y = region)) + geom_col(fill = "steelblue") 

# Pregunta 8)
#- Venga, un scatterplot entre x = PIB_percapita   e y = esperanza_vida Con los datos del año 2017 y que los puntos tengan un color diferente en función de la región. Añade geom_smooth() calculado para todas las observaciones de 2017

p <- ggplot(df_2017, aes(x = PIB_percapita, y = esperanza_vida)) + 
    geom_point(aes(color = region)) + 
    geom_smooth() 
p


# Pregunta 9)
#- Intenta mejorar el último gráfico todo lo que puedas. Recuerda que puedes utilizar el asistente  ggThemeAssist.

p + theme(plot.subtitle = element_text(vjust = 1), 
          plot.caption  = element_text(vjust = 1), 
          panel.grid.major = element_line(colour = "white", linetype = "dashed"), 
          panel.background = element_rect(fill = "aliceblue"), 
          plot.background  = element_rect(fill = "aliceblue", linetype = "longdash")) +
          labs(title = "PIB percapita frente a esperanza de vida")

# Pregunta 10)
#- Haz un mapa (una coropleta) del mundo. Los colores de los países han de estar en función de los valores de la esperanza de vida en 2017 (divide los países en cuatro grupos o cuartiles)
#- yo os ayudo a buscar los datos de las geometrías de los países. Uso los siguientes paquetes
rm(list = setdiff(ls(), c("df", "df_2017") ))

library("rnaturalearth")
library("rnaturalearthdata")
world <- ne_countries(scale = "medium", returnclass = "sf")

#- quito Antarctica y Groenlandia
world <- world %>% filter(subregion != "Antarctica") %>% filter(admin != "Greenland")
ggplot() + geom_sf(data = world) + theme_void()

world <- world %>% select(name, iso_a3, geometry) #- me quedo solo con las 2/3 variables que me hacen falta

#- primero has de unir las tablas "df" y "world". la variable de union es by = c("iso3c" = "iso_a3")
df_world <- left_join(df_2017, world, by = c("iso3c" = "iso_a3") ) 

#- una vez hemos unido las tablas solo hay que graficarlo con geom_sf(), pero antes has de discretizar la variable Esperanza de vida en 4 grupos. ¿te acuerdas de la funcion ntile()

df_world <- df_world %>% mutate(esperanza_vida_4 = as_factor(ntile(esperanza_vida, 4))) #- como factor
df_world <- df_world %>% mutate(esperanza_vida_4a = ntile(esperanza_vida, 4))           #- como integer


str(df_world)


#- para hacer el mapa tendrás que usar geom_sf() y tendrás que usar las estéticas geometry y fill. Recuerda que las estéticas siempre van dentro de aes()

p <- ggplot(df_world) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4))
p
p + scale_fill_viridis_d()

p + scale_fill_brewer()
p + scale_fill_brewer(palette = "Greens")


#- voy a usar una escala continua (no es buena idea, pero ...)
ggplot(df_world) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4a)) + scale_fill_viridis_c()


#-scale_fill_manual(values = c('gray90','steelblue1','steelblue4'), name = "Esperanza de vida", labels = c("Absent", "Occasional", "Regular"))


#- Pregunta 11)
#- Haz el mismo mapa pero un small multiple para los años 2000, 2005, 2010 y 2017

df_small <- df %>% filter(date %in% c(2000, 2005, 2010, 2017))

df_world <- left_join(df_small, world, by = c("iso3c" = "iso_a3") ) 

#- para discretizar hay que hacerlo para cada año por separado
df_world <- df_world %>% group_by(date) %>% mutate(esperanza_vida_4 = as_factor(ntile(esperanza_vida, 4)))

p <- ggplot(df_world) + geom_sf(aes(geometry = geometry, fill = esperanza_vida_4)) + 
       facet_wrap(vars(date))
p


p + scale_fill_viridis_d() #- con los colores q se ven en la referencia visual
